# cherry-studio 架构深化研读（代码级）

- 日期：2026-08-15
- 研读对象：Dev/参考项目/cherry-studio（仅只读，未修改任何参考项目文件）
- 任务：把 8-14 计划中的宏观条目落到「可直接抄的数据结构/算法/函数签名」级，聚焦 provider 目录生成管线、ProviderExtension 注册表、模型能力三层探测、IPC schema 单点声明、流式架构、SeedRunner、Drizzle 迁移 FK、消息树
- 关联：`Dev/Main/Archive/参考项目深化研读与借鉴吸收-2026-08-15.md`（已吸收 8-14 计划；8-14 原档已删）
- 说明：本报告所有 file:line 均相对参考项目根目录；全部结论均经 read/grep/glob 逐行核对
- 归档：2026-08-24 移入 Archive/（原 04-调研/；所支撑的 8-15 借鉴计划已收口归档）。

---

## 一、总体认知

本专题在 cherry-studio 里是「**数据目录（provider-registry）+ 进程间通信（shared/ipc）+ 主进程流式运行时（main/ai/streamManager）+ 持久化（main/data/db）**」四层咬合的结构，核心信条是「**单一事实源，其余全部推导**」：

1. **provider-registry 包分两副面孔**：构建期是「手写源码（creators/providers）→ generate-catalog.ts → data/*.json 纯生成物 + 编译产物 .gen.ts」；运行期是「schema（zod）验证 + RegistryLoader 缓存/索引/查询」。`data/*.json` 与 `*.gen.ts` 都严禁手改，CI 双向守卫（`catalog-hand-edit-check` 拒「改了 JSON 没改源码」，`catalog-source-sync` 测试拒「改了源码没重新生成」）。生成物版本号用**内容哈希**（contentVersion）而非日期戳，是 seeding 跳过的判据。
2. **shared/ipc 是类型层的单点声明**：`defineRoute({input, output})` 一处声明，`IpcHandlersFor<S>` 让 handler 签名、renderer facade、事件负载全部由 schema 推导，缺失/多余 handler 是编译错误；`IpcRouter` 永远 safeParse + `Object.hasOwn` 防原型链注入；`IpcContext` 只暴露 senderId。zod **值**不进入 renderer 包（`import type` 纪律），错误用 `{ok,data}|{ok:false,error}` 信封过边界。
3. **AiStreamManager 是「主进程拥有流」的实现**：每 topic 至多一个活动流，`pipeStreamLoop` 把流 `tee()` 成「广播 + 累积」两路；广播路走多 listener 同步 fan-out（每个执行还带 ring buffer 供迟到订阅者回放），累积路走 AI SDK `readUIMessageStream` 得到最终消息。steer（打断插话）语义是「入队 + 让出 + 续链」，不是中止重启。
4. **持久化层**：`applyMigrations` 处理 Drizzle 迁移的 FK 坑（事务内 PRAGMA 失效 → 表重建级联删数据）；`SeedRunner` 用 appState 表记 journal（`seed:<name>` → version），版本用内容哈希；`message` 表用邻接表 parentId + siblingsGroupId + compactionSummary + ftsRowid 支撑分支对话/持久压缩/FTS。

「只读参考、绝不修改」已遵守；本报告只写入 Dev/Main/04-调研/。

---

## 二、深化条目

### 2.1 provider 目录生成管线：generate-catalog.ts 完整流程 + contentVersion 内容哈希

- **代码位置**：packages/provider-registry/scripts/generate-catalog.ts（全文件 685 行）；配套 canonicalize.ts（canonOf/prefixHit/splitOverrideWireId）、upstream.ts（上游解析）
- **核心数据结构与算法摘录**：

```ts
// generate-catalog.ts:60-67 —— 版本 = 内容哈希（SHA-256 前 16 位）
const contentVersion = (body: unknown): string =>
  createHash('sha256').update(JSON.stringify(body)).digest('hex').slice(0, 16)

// generate-catalog.ts:230-234 —— 写盘唯一形态：key 排序 → 盖 version 戳
const stampAndSerialize = (body: Record<string, unknown>): string => {
  const sorted = sortKeys(body)
  return JSON.stringify(sortKeys({ ...sorted, version: contentVersion(sorted) }), null, 2) + '\n'
}
```

- **sortKeys**（:252-261）：递归按 key 排序数组/对象——保证「相同内容 ⇒ 相同 version」。
- **load()**（:263-275）：`MODELSDEV_CACHE`/`OPENROUTER_CACHE`/`OPENROUTER_IMAGE_CACHE` 环境变量给本地缓存文件，否则 live fetch，**全部用 zod schema 校验顶层结构**（`ModelsDevApiSchema`/`OpenRouterApiSchema`）。
- **主流程**（:614-685）：load 上游 → `buildIndex`（canonId → 跨源元数据 union）→ `assignCreators`（三趟认领）→ `buildModels`（models.json）→ `buildProviders`（providers.json）→ `buildProviderModels`（provider-models.json）→ 再生成 3 个 `.gen.ts` 编译产物。
- **buildIndex**（:287-323）：models.dev **只读** creator 前向声明的 `modelsDevProviders`（干净清单，host/gateway 忽略——不然会注入 host 前缀重复 id）；OpenRouter 全读。元数据跨源 union（一个 host 少报能力不会被另一个 host 藏掉）。`stripHostReprefix` 折叠 `databricks-gemini-3-flash → gemini-3-flash`，以 index 本身为 oracle，不是硬编码 host 表。
- **assignCreators 三趟认领**（:326-380）：pass1 显式身份（fetchModels / 手写 models / idPrefixes，`deepseek-r1-distill-qwen` 归 deepseek 而非 alibaba family `qwen`）；pass2 family（base 架构，弱于显式 id）；pass3 provider 清单兜底（gate 在折叠后的 index 上，host 不能复活被折叠的重复）。
- **buildProviders**（:477-493）：丢弃 generation-only 字段（`modelsDevProvider`/`fetchModels`/`overrides`），`serverTools` 里剥离模型选择器，description 模板化成 `"{name} - AI model provider"`。
- **buildProviderModels**（:502-612）：**纯由 src/providers 推导**（generation 是源码的纯函数），每个 provider 的 `overrides` + models.dev 定价行；dedup 键是 `providerId modelId apiModelId variantsKey`。OpenRouter reasoning/image 目录补充进精确行（`apiModelId` 匹配优先）。
- **`*.gen.ts` 编译产物**（:89-110, :160-177, :209-228）：`reasoning-families.gen.ts`、`server-tool-models.gen.ts`、`server-tool-constraints.gen.ts`——把 creator/provider 声明的 ID 模式**编译成精确 id 数组**，运行期零 regex。注释明言「编译成精确 id 可防宽泛 family 前缀泄漏到新发现的兄弟型号上」（:113-116）。
- **canonicalize.ts**（独立模块，可单测）：`canonOf`（:24-34）构建期折叠——**刻意不剥参数尺寸**（目录保留 `qwen3-235b` ≠ `qwen3-30b`），与运行期 `normalizeModelId` 的一个有意分歧（文件头 :1-8 说明）。`prefixHit`（:37-38）：`-` **或** digit 结束前缀词，所以 `qwen` 同时认领 `qwen-max` 和 `qwen3-30b-a3b`。`splitOverrideWireId`（:47-53）：override 不写 `apiModelId` 时，把 `modelId` 规范化成 catalog key，**原始拼写升为 apiModelId**——运行期发送 `apiModelId ?? modelId`，不 split 的话 `glm-5.2` 会被规范成 `glm-5-2` 上 wire 而 404。
- **设计理由与踩坑**：
  - 版本用内容哈希而非日期戳的理由写得很明确（:60-65）：**同一天重新生成可能改内容但日期不变 → seeder 会静默永不跑**。这是「SeedRunner 跳过依据」与「生成物版本」的直接咬合点。
  - generation 是「源码的纯函数」这一原则让 `catalog-source-sync` 测试**可以离线确定性重算**（不 fetch 上游，只重算源码能决定的事实，见 第2.6节）。
  - `canonOf` 与 `normalizeModelId` 曾分叉（build 剥 MMDD/YYMM 日期、runtime 不剥），后来合并为共享 helper——测试里有专门断言「build canonicalizer and runtime resolver agree on dated ids」（normalize.test.ts:60-63）。
- **对 CLWriting 的具体借鉴与适配建议**：
  - 我们刚完成的表驱动三格式重构，可对照补齐「**源数据 + 生成物 + CI 双向校验**」三件套：`src/.../providerDefs.ts`（手写源码）→ 一个 `generate-catalog.ts` 等价脚本 → 生成 `data/providers.json` 等；版本号用**内容哈希**（`sha256(JSON.stringify(sortKeys(body))).slice(0,16)`），这样表驱动数据入库时的 seeder 能正确跳过。
  - CI 双向校验可以直接照搬：一个 workflow job 用 `git diff --name-only` 判「改了 data/*.json 但没改 src/」→ 拒绝；一个 vitest 测试从 src **离线重算**（stable stringify 后 diff）判「改了 src 没重新生成」——**不要**做「跑 generate 再 diff」因为上游 fetch 会让它 flaky（catalog-source-sync.test.ts:1-14 的开头注释就是踩坑记录）。
  - `prefixHit` 的「`-` 或 digit 结尾前缀词」规则、`splitOverrideWireId` 的「原始拼写升为 wire id」模式，在我们 provider 表驱动层的 id 归一化里可直接抄。
- **成本与优先级**：中。生成脚本 + CI 双向校验 ≈ 200-300 行；对刚重构完的表驱动层是「补闭环」而非新增，建议进批次 D。

### 2.2 models.json / providers.json / provider-models.json 的 schema 字段

- **代码位置**：packages/provider-registry/src/schemas/{model,provider,provider-models,common,enums}.ts
- **核心 schema 摘录**：

```ts
// model.ts:391-450 ModelConfigSchema（models.json 的行）
id / name / description? / capabilities?(去重 refine) / inputModalities? / outputModalities?
contextWindow? / maxOutputTokens? / maxInputTokens?
pricing? (ModelPricingSchema: input/output + cacheRead/cacheWrite + perImage + perMinute)
reasoning? (ReasoningSupportSchema) / parameterSupport? / imageGeneration?
family? / ownedBy? / openWeights? / metadata (z.record 任意)
// 容器：ModelListSchema = { version: VersionSchema, models: [...] }

// provider.ts:140-216 ProviderConfigSchema（providers.json 的行）
id / presetProviderId? / name / description? / endpointConfigs?(record<EndpointType, RegistryEndpointConfig>)
defaultChatEndpoint?(nullable, refine: 必须是 endpointConfigs 的 key)
modelListSource?('api'|'registry' 默认 api) / authMethods?(['api-key','oauth','external-cli'])
authOptional?(默认 false) / serverTools? / apiFeatures? / reportedCostCurrency / fastMode? / metadata
// RegistryEndpointConfigSchema (provider.ts:114-138): baseUrl? / modelsApiUrls?(default/embedding/image/reranker) / reasoningFormat? / adapterFamily?

// provider-models.ts:54-117 ProviderModelOverrideSchema（provider-models.json 的行）
providerId / modelId（引用 models.json 的规范化 id） / apiModelId?（wire 真实 id）
modelVariants?（['thinking','free'] 排序后参与唯一键）/ capabilities?({add,remove,force})
limits?({contextWindow,maxOutputTokens,maxInputTokens}) / pricing?(partial) / reasoningContracts?(按 endpoint key)
supportsFastMode? / parameterSupport?(partial) / endpointTypes? / inputModalities? / outputModalities?
name?/description?/family?/ownedBy?（standalone：modelId 在 models.json 无行时据此合成 ModelConfig）
imageGeneration? / disabled? / replaceWith? / reason?
```

  - **enums.ts 的三点纪律**：`as const` 对象 + kebab-case（可调试）；`objectValues()` 辅助把 const 对象值转成 `z.enum` 元组（:210-211）；`CANONICAL_PARAM_KEY` 特意用 **camelCase**（它们就是运行期 param-bag key，kebab 会破坏 wire 契约，:86-100）。新增一个 param 是**刻意变更**：加 enum 成员 + 加 label + 在模型上声明。
  - **common.ts:19**：`VersionSchema = z.string().min(1)`——注释明言「opaque，别解析它」（旧生成物带过日期，当成不透明 token）。
  - **ParameterSupportSchema**（model.ts:329-356）：temperature/topP/topK 有 `{supported, range?}`，frequencyPenalty/presencePenalty/maxTokens/stopSequences/systemMessage 是布尔，全部带默认值——**这是「模型支持哪些旋钮」的模板**。
- **设计理由与踩坑**：
  - provider-models 的 `apiModelId` 字段是 cherry 的招牌设计：目录行存「规范化 id」（引用 models.json），wire 上发 `apiModelId ?? modelId`——一个 canonical 模型可被一个 provider 用多个 apiModelId 服务（tokenhub 的带日期原厂直供变体），每个变体是独立可选模型。
  - `CapabilityOverrideSchema` 的三元组 `add/remove/force`（provider-models.ts:23-27）：`force` 是「忽略 base config 强制设值」，比只有 add/remove 多了覆盖语义。
  - 注意 `imageGeneration` 在模型级与 override 级都有，override 级优先（provider-models.ts:106-109 注释：同一模型 id 可对 provider 声明不同参数）。
- **对 CLWriting 的借鉴**：我们 provider 表驱动层若已有「模型能力表 + provider 连接表 + provider-model 覆盖表」，可对齐这套字段命名（尤其 `apiModelId` 与「standalone name」的分离——vendor 独占模型不必污染全局 models 表）；`add/remove/force` 能力覆盖三元组、`{supported, range?}` 参数支持形状可直接抄。
- **成本与优先级**：低-中（纯 schema 对齐，若表驱动结构已定则改动小）。批次 D。

### 2.3 RegistryLoader.findModel 三套索引 + 归一化规则（精确 / 归一化 / 保留参数尺寸）

- **代码位置**：packages/provider-registry/src/registry-loader.ts:58-288；归一化规则在 utils/normalize.ts（全文件 353 行）
- **核心算法摘录**：

```ts
// registry-loader.ts:143-160 buildModelIndex —— 三套模型索引
private buildModelIndex(): void {
  this.modelById = new Map(); this.modelByNormId = new Map(); this.modelBySizedNorm = new Map()
  for (const m of this.models!) {
    this.modelById.set(m.id, m)
    const nid = normalizeModelId(m.id)
    if (!this.modelByNormId.has(nid)) this.modelByNormId.set(nid, m)          // 尺寸无关键
    const sid = normalizeModelId(m.id, { keepParameterSize: true })           // 保留尺寸键
    if (!this.modelBySizedNorm.has(sid)) this.modelBySizedNorm.set(sid, m)
  }
}

// registry-loader.ts:213-231 findModel —— 查找顺序 = 精确 → 尺寸优先 → 尺寸无关兜底
findModel(modelId: string): ModelConfig | null {
  const exact = this.modelById!.get(modelId); if (exact) return exact
  if (colonVariantTagToHyphen(modelId) !== modelId) {   // 带 :20b 的 registry-tag id 先按尺寸匹配
    return this.modelBySizedNorm!.get(normalizeModelId(modelId, { keepParameterSize: true })) ?? null
  }
  const sizedModelId = normalizeModelId(modelId, { keepParameterSize: true })
  const sizedHit = this.modelBySizedNorm!.get(sizedModelId); if (sizedHit) return sizedHit
  if (extractParameterSize(sizedModelId)) return null   // 请求带尺寸但目录无此尺寸行 → 宁缺勿错
  return this.modelByNormId!.get(normalizeModelId(modelId)) ?? null
}
```

  - **override 侧有 9 个索引**（buildOverrideIndex :162-211）：`overrideByKey / overrideByNormKey / overrideBySizedNormKey / overrideByApiKey / overrideByNormApiKey / overrideBySizedNormApiKey / overridesByProvider`。两个关键规则：
    - **self-variant 优先**（:176-178, :189-191）：canonical key 冲突时 `apiModelId === modelId` 的行（无日期原厂直供）总是抢占 slot——**顺序无关**（测试 registry-loader.test.ts:58-61 断言 dated 在前 undated 在后也解析到 undated）。
    - **findOverride 顺序**（:238-257）：精确 key 与精确 apiKey **都先于** 归一化 fallback，否则 `google.gemma-3-27b-it` 会经归一化 `gemma-3-it` 落到同族兄弟 12b 上（:243-245 注释，registry-loader.test.ts:74-95 专门测这个）。
  - **normalizeModelId 全管线**（normalize.ts:326-353）：

```
split('/') 取末段 → toLowerCase → stripAggregatorPrefixes（聚合前缀表 :13-55）
→ stripBedrockVendorPrefix（[region.]vendor. / vendor-）→ stripBedrockRevision（…-v1:0）
→ expandKnownPrefixes（mm- → minimax-，:57-59）
→ keepParameterSize 时先 colonVariantTagToHyphen（:20b → -20b）
→ 不动点循环 stripVariantQuantDateSuffixes ∘ (可选)stripParameterSize
→ normalizeVersionSeparators（3.5/3,5/3p5/3_5 → 3-5，:260-263）
→ _ 全折叠成 -
```

  - **关键常量**（normalize.ts:105-139）：`PARAMETER_SIZE_PATTERN = /-(\d+(?:\.\d+)?b)(?=-|$)/i`；`COLON_VARIANT_TAG_PATTERN`（只对齐 size/quant leader，`:free`/`:0` 不动，:113）；`QUANTIZATION_SUFFIXES = ['-fp8','-fp16','-bf16','-awq','-int4','-int8','-gguf','-gptq']`；`DATE_SNAPSHOT_PATTERN`（:126-127，**要求合法月份 01-12 与日期 01-31**，所以 `glm-4-9b`、`qwen3-235b` 永不误剥——测试 normalize.test.ts:49-58）；`HYPHEN_VARIANT_SUFFIXES` 里**特意不含 `-medium`**（它是真 tier 名 `mistral-medium`，剥了会成 `mistral` 错stem，:83-85 注释）。
  - **stripVariantQuantDateSuffixes 不动点**（:284-291）：单趟是顺序依赖的（尾部日期会遮住内层 variant，`…-thinking-2507` 必须先剥日期才暴露 `-thinking`），所以循环到稳定。这是「单趟不可幂等」的经典坑。
  - **30s 空闲 TTL 缓存**（registry-loader.ts:49-91）：`touch()` 每次访问重置定时器，超时 `invalidate()` 全清（8 个模型/override 索引 + version 全置 null），下次访问懒加载。
- **设计理由与踩坑**：所有注释都是真实踩坑史——归一化塌缩（`gpt-oss-20b`/`gpt-oss-120b` → 同 `gpt-oss`）、gateway 重命名空间（`nvidia/gpt-oss-20b` 必须落到**自己尺寸**的行）、「请求带尺寸但目录无此尺寸 → 返回 null 而非猜尺寸无关行」（错的 pricing/limits 比没有元数据更糟，:218-221）。
- **对 CLWriting 的借鉴**：我们的模型能力探测若还在用「精确 id 查找」或裸 regex，可直接搬「精确 → 保留尺寸归一化 → 尺寸无关归一化」三键 + `extractParameterSize` 存在时宁缺勿错；`keepParameterSize` 语义（尺寸是 id 的一部分，不是可剥后缀）尤其适用于我们有多个同族尺寸模型时。30s 空闲 TTL 缓存对数据小则不必。
- **成本与优先级**：中（normalize.ts 是一套完整可单测的纯函数库，照抄 + 裁剪到我们需要的规则即可）。批次 D（替代/补充已退役的 probeModelCaps）。

### 2.4 模型能力三层探测：endpointImpliedCapability 推导表 + inferAdapterFamily

- **代码位置**：packages/provider-registry/src/registry-utils.ts:88-140
- **核心推导表摘录**：

```ts
// registry-utils.ts:126-140 —— 能力排他端点 → 模型能力（chat 端点不在表里，推导不出任何能力）
const ENDPOINT_IMPLIED_CAPABILITY: Partial<Record<EndpointType, ModelCapability>> = {
  [ENDPOINT_TYPE.JINA_RERANK]: MODEL_CAPABILITY.RERANK,
  [ENDPOINT_TYPE.OPENAI_AUDIO_TRANSCRIPTION]: MODEL_CAPABILITY.AUDIO_TRANSCRIPT,
  [ENDPOINT_TYPE.OPENAI_AUDIO_TRANSLATION]: MODEL_CAPABILITY.AUDIO_TRANSCRIPT,
  [ENDPOINT_TYPE.OPENAI_EMBEDDINGS]: MODEL_CAPABILITY.EMBEDDING,
  [ENDPOINT_TYPE.OPENAI_IMAGE_GENERATION]: MODEL_CAPABILITY.IMAGE_GENERATION,
  [ENDPOINT_TYPE.OPENAI_IMAGE_EDIT]: MODEL_CAPABILITY.IMAGE_GENERATION,
  [ENDPOINT_TYPE.OPENAI_TEXT_TO_SPEECH]: MODEL_CAPABILITY.AUDIO_GENERATION,
  [ENDPOINT_TYPE.OPENAI_VIDEO_GENERATION]: MODEL_CAPABILITY.VIDEO_GENERATION
}
export function endpointImpliedCapability(endpointType): ModelCapability | undefined {
  return endpointType ? ENDPOINT_IMPLIED_CAPABILITY[endpointType] : undefined
}

// registry-utils.ts:88-115 inferAdapterFamily —— 目录 adapterFamily → 端点默认 → openai-compatible 兜底
const ENDPOINT_TYPE_TO_DEFAULT_ADAPTER_FAMILY = {
  'anthropic-messages': 'anthropic', 'google-generate-content': 'google',
  'ollama-chat': 'ollama', 'ollama-generate': 'ollama',
  'jina-rerank': 'jina-rerank', 'openai-responses': 'openai'
}
export function inferAdapterFamily(endpointType, catalogConfig?): string {
  if (catalogConfig?.adapterFamily) return catalogConfig.adapterFamily
  return ENDPOINT_TYPE_TO_DEFAULT_ADAPTER_FAMILY[endpointType] ?? 'openai-compatible'
}
```

- **三层探测如何组装**：
  - 第一层：models.json 的 `capabilities`/`contextWindow` 等目录行（查得到就用）。
  - 第二层：目录查不到时用端点推导——`listModels.ts:460` 用 `endpointTypes.find(endpointImpliedCapability(ep) === undefined)` 找 chat 主端点；`listModels.ts:485` 用 `endpointImpliedCapability(endpointTypes?.[0])` 给 opaque gateway/NewAPI 模型补能力；`AiService.checkModel`（AiService.ts:1119）用 `endpointImpliedCapability(primaryEndpoint) === undefined` 判「chat-primary」，决定探活走 rerank / embed / text。
  - 第三层：`inferAdapterFamily` 是**写时推导**（seeder/migrator/UI 创建路径用），运行期只读（registry-utils.ts:99-101 注释）。
  - `normalizeEndpointTypes`（listModels.ts:441-467）里有个细节：embedding 端点排在首位时，**把 chat 端点挪到第一位**再返回——多端点模型优先当 chat 用。
- **设计理由与踩坑**：能力探测是**纯数据查找，不调模型**（旧报告 CS-3 已说）；endpoint 表刻意**排除 chat/completions 端点**（它们通用、不推导能力）。`endpointImpliedCapability` 也用于 v2 迁移映射（ProviderModelMappings.ts:502），是单一事实源跨路径复用。
- **对 CLWriting 的借鉴**：我们的「是否支持 JSON 输出 / 上下文长度 / 是否支持多轮」能力可做「预设表 → ID 规则推导 → 保守默认」三层，`endpointImpliedCapability` 这种「端点排他 → 能力」的表可以直接照搬（如 rerank 端点 → 只 rerank）。
- **成本与优先级**：低。批次 D。

### 2.5 ProviderExtension 注册表 + adapterFamily 字符串路由

- **代码位置**：src/main/ai/provider/extensions.ts（全部 388 行）；packages/aiCore/src/core/providers/core/ProviderExtension.ts；registry-utils.ts inferAdapterFamily 是路由键解析器
- **核心数据结构摘录**：

```ts
// extensions.ts:45-62（一个典型 extension）—— 声明式一行注册 + 懒加载 + 工具工厂
export const GoogleVertexExtension = ProviderExtension.create({
  name: 'google-vertex',
  aliases: ['vertexai'] as const,
  supportsImageGeneration: true,
  create: async (settings) => (await import('@ai-sdk/google-vertex/edge')).createVertex(settings),
  toolFactories: {
    webSearch: (provider) => (config) => ({ tools: { webSearch: provider.tools.googleSearch(config) } })
  }
} as const satisfies ProviderExtensionConfig<GoogleVertexProviderSettings, GoogleVertexProvider, 'google-vertex'>)
// extensions.ts:360-388 把所有 extension 收进一个数组导出
```

  - **ProviderExtensionConfig**（ProviderExtension.ts:25-103）：`name` + `aliases` + `defaultOptions` + `supportsImageGeneration` + `variants` + `toolFactories` + `createRerankingModel`；`create` 与 `import+creatorFunctionName` **互斥**（联合类型，:62-103）。
  - **实例缓存按 settings hash**（ProviderExtension.ts:165-235）：`computeHash` 做稳定 stringify（函数按 WeakMap 编号，循环引用标 `"[circular]"`，key 排序）→ QuickLRU maxSize=10 缓存；`pendingCreations` 防并发创建同 settings。`getProviderIds()`（:319-329）= name + aliases + `${name}-${variant.suffix}`。
  - **adapterFamily 路由链**（ProviderRegistryService.ts:818）：`presetConfig?.adapterFamily ?? rowConfig?.adapterFamily ?? inferAdapterFamily(ep)`——目录 adapterFamily（编码 vendor 特殊中继，如 AiHubMix 的 anthropic-messages 走 aihubmix）→ 端点默认 → openai-compatible 兜底。
- **设计理由与踩坑**：新增服务商 = 一行声明 + 懒加载，SDK 包不在启动时加载；`as const satisfies` 让 name 的字面量类型贯穿。DeepSeek 是自定义 adapter（`adapterFamily: 'deepseek'`），OpenAI-compatible 不是万能。
- **对 CLWriting 的借鉴**：provider 表驱动层加一个「adapter 注册表」列——每个 SDK 接入变成声明式 `{ name, aliases, create: lazy import }`，adapterFamily 字符串成为唯一运行时路由键；「按 settings hash 缓存 provider 实例 + LRU」防止每次请求重建连接对象。
- **成本与优先级**：低-中。批次 D。

### 2.6 IPC schema 单点声明：defineRoute / IpcHandlersFor / IpcRouter / IpcApiService

- **代码位置**：src/shared/ipc/{define.ts,types.ts,schemas/ipcSchemas.ts,schemas/ai.ts}；src/main/ipc/{IpcRouter.ts,IpcApiService.ts,handlers/ai.ts}；src/preload/ipc.ts；src/renderer/ipc/ipcApi.ts；src/shared/ipc/errors/IpcError.ts
- **核心类型体操摘录**：

```ts
// define.ts:9-23 —— 一处声明（运行时恒等函数，纯为捕获类型）
export interface RouteDef { input: ZodType; output: ZodType }
export const defineRoute = <D extends RouteDef>(def: D): D => def

// types.ts:39-41 —— 让 handler 签名由 schema 推导（穷尽 + 封闭）
export type IpcHandlersFor<S extends Record<string, RouteDef>> = {
  [R in keyof S]: (input: z.infer<S[R]['input']>, ctx: IpcContext) => Promise<z.infer<S[R]['output']>>
}
// types.ts:19-28 —— 只暴露 senderId，绝不暴露 WebContents/event
export interface IpcContext { senderId: WindowId | null }

// renderer/ipc/ipcApi.ts:34-37 —— void input 走变参条件元组，不需要第二参
request: <R extends IpcRoute>(route: R,
  ...args: InputFor<R> extends void ? [] : [input: InputFor<R>]
): Promise<OutputFor<R>> => unwrap<OutputFor<R>>(window.api.ipcApi.request(route, args[0]))

// IpcRouter.ts:23-43 —— Object.hasOwn 防原型链注入 + 永远 safeParse + 不接 handler 错误
if (!Object.hasOwn(this.schemas, route)) {
  throw new IpcError(IpcErrorCode.ROUTE_NOT_FOUND, `Unknown IpcApi route: ${route}`)
}
const parsed = def.input.safeParse(input)
if (!parsed.success) {
  throw new IpcError(IpcErrorCode.VALIDATION_FAILED, `Invalid input for ${route}`, { issues: parsed.error.issues })
}
```

  - **全局注册表**（ipcSchemas.ts:46-83）：每个域 `*RequestSchemas` 对象 spread 进 `ipcRequestSchemas satisfies Record<string, RouteDef>`，`IpcRoute = keyof IpcRequestSchemas`。事件侧是纯类型交集 `IpcEventSchemas = A & B & ...`。
  - **zod 值不进 renderer**（ipcSchemas.ts:39-45）：renderer 必须 `import type`，schema 值只在 main 出现；`IpcError` 是纯 TS 无 zod，可安全作为值导入（renderer ipcApi.ts:8-12 注释）。
  - **preload 是泛型桥**（preload/ipc.ts:12-23）：`request(route, input, meta?)` + `on(event, cb)`，单通道 `IpcApi_Request`/`IpcApi_Event`，加路由零改动；type 校验在 renderer facade 层。
  - **IpcApiService 传输层**（IpcApiService.ts:51-116）：`validateSender(event)` 源信任门（frame URL allowlist）→ `router.dispatch` → 结果包 `{ok:true,data} | {ok:false,error}` 信封（**绝不 throw 给 ipcMain.handle**，因为 Electron 的 reject 只留 message 丢 code/data，:74-77）；`makeContext` 用 `WindowManager.getWindowIdByWebContents(event.sender) ?? null`，**伪造 windowId 提权面被切断**（:86-88）。`broadcast`/`send` 有 `isDestroyed()` 守卫（:100-115，closed 事件晚一 tick 的坑）。
  - **错误模型**（IpcError.ts:25-81）：`IpcErrorCode` 常量 const + `(string & {})` 尾巴保持开放（跨边界重建时封闭联合是谎言）；`IpcError.from()` 把任意 throw 归一成 INTERNAL。
- **设计理由与踩坑**：
  - `Object.hasOwn` 的注释（IpcRouter.ts:24-30）：裸 `schemas[route]` 会把 `__proto__`/`constructor`/`toString` 解析成 truthy 的 Object.prototype 值，躲过真值检查变成 INTERNAL TypeError。
  - `IpcHandlersFor` 需要 `extends Record<string, RouteDef>` 约束，否则 TS 无法证明 `S[R]` 有 input/output（types.ts:36-38 注释 TS2536）。
  - input schema 镜像 **wire 形状**而非进程内类型：`AbortSignal`、`ToolSet` 这类不可 structured-clone 的字段**刻意不在** input 里（schemas/ai.ts:42-50 注释）；output 用 `z.custom<T>()` 装 opaque AI SDK 类型——router 从不 parse output，output 由可信 main 构造（ipc-migration-guide 的取舍）。
- **对 CLWriting 的借鉴**：主进程 IPC（我们已有 IPC 层）引入「schema 单点声明 + 类型推导 + senderId-only context」；`Object.hasOwn` 防注入一行就能加；「错误信封 + `IpcError.from()` 归一」可直接照搬；「renderer 只 `import type` schema」让我们这类带 zod 依赖的项目避免 schema 值进 bundle。
- **成本与优先级**：中（需要逐步迁移现有路由，每域一个 `*RequestSchemas` 对象）。批次 E。

### 2.7 流式架构：pipeStreamLoop 的 tee + 广播 fan-out + readUIMessageStream 累积

- **代码位置**：src/main/ai/streamManager/pipeStreamLoop.ts（全 103 行）；AiStreamManager.ts onChunk（:1139-1241）、dispatchToListeners（:1899-1930）、runExecutionLoop（:1748-1848）、addListener（:1051-1065）
- **核心算法摘录**：

```ts
// pipeStreamLoop.ts:40-85 —— tee 两路，signal 只取消广播路
export async function pipeStreamLoop(stream, signal, options) {
  const [forBroadcast, forAccum] = stream.tee()
  let finalMessage
  const accumulator = runAccumulator(forAccum, options.accumulatorSeed, (msg) => {
    finalMessage = msg; options.onAccumulatedSnapshot?.(msg)
  }).catch(() => { /* 累积失败非致命：广播路拥有终态 */ })

  const broadcastReader = forBroadcast.getReader()
  const onAbort = () => { void broadcastReader.cancel(signal.reason).catch(() => {}) }
  if (signal.aborted) onAbort(); else signal.addEventListener('abort', onAbort, { once: true })

  let streamErrorText, threw, broadcastCompletedAt
  try {
    while (true) {
      const { done, value } = await broadcastReader.read()
      if (done) break
      if (value.type === 'error') streamErrorText ??= value.errorText
      options.onChunk(value)
    }
    broadcastCompletedAt = performance.now()
  } catch (error) { threw = { error }; broadcastCompletedAt = performance.now() }
  finally { signal.removeEventListener('abort', onAbort); broadcastReader.releaseLock() }

  await accumulator
  return { finalMessage, streamErrorText, threw, broadcastCompletedAt }
}
```

  - **为何 signal 只取消广播路**（pipeStreamLoop.ts:9-13 契约）：累积路让 `Agent.stream` 沿同一 signal 自然排干；直接取消累积 reader 会和 AI SDK 的 `controller.close()` 竞态出 `ERR_INVALID_STATE`。
  - **runAccumulator**（:87-103）：`readUIMessageStream<CherryUIMessage>({ stream, message: seed })`——`continue-conversation` 必须 seed 已有 assistant 消息，否则 `getToolInvocation` 抛错静默停累积（AiStreamManager.ts:1796-1801 注释）。seed 取 `request.messages?.at(-1)` 且 role 为 assistant。
  - **onChunk 同步 fan-out**（AiStreamManager.ts:1139-1241）：每 chunk → 构造 `StreamChunkPayload{topicId, executionId(=modelId), attemptId, anchorMessageId, chunk}` → 同步遍历 listeners（`onChunk` 必须不阻塞 loop，listener 抛错只 warn）→ 顺带 scrub 死 listener。`pendingApprovalToolCallIds` 是审批生命周期的权威捕获（按 toolCallId，避免兄弟 tool 的输出清掉另一个 pending 审批）。
  - **每执行 ring buffer**（:1186-1209）：`splitDeltaPayload` 按 `maxDeltaBytes: 16_384` 切超大 delta，尾部合并（`mergeDeltaPayload`，同 part 连续 delta 折叠成一条）——**cap 数协议单元（part/tool 事件）而非原始 delta**，否则 delta 洪泛会把自己的 part 开头 chunk 挤出、回放不可 parse。超限 `buffer.shift()` + `droppedChunks++`；审批 pending 时暂停驱逐（审批的 tool-input chunk 是重连必须重放的活状态）。
  - **迟到订阅者回放**（addListener :1051-1065）：新 listener 加入时从**每个 execution 的 ring buffer** 顺序重放——多模型 topic 由 renderer 按 executionId+anchor 去重。
  - **dispatchToListeners 相位排序**（:1899-1930）：终态事件按 `terminalPhase` 排序——persistence 先、普通次之、cleanup 最后；persistence listener 抛 `TerminalPersistenceError` 时 `suppressNotification` 抑制普通通知（持久化失败就别再通知用户「成功」）。
  - **withIdleTimeout**（:1790-1794）：空闲 chunk 定时器超时 abort `exec.abortController`（上游 AI SDK 请求已接 signal）；审批 pending 时重设成宽松的 `approvalIdleTimeoutMs = 2h`（:1806-1811）。
  - **DEFAULT_CONFIG**（:161-170）：`gracePeriodMs: 30_000`、`backgroundMode: 'continue'`、`maxBufferChunks: 10_000`、`maxDeferredOutputs: 64`。
- **设计理由与踩坑**：渲染进程崩溃/关窗**不 abort 流**（Main owns persistence）；`backgroundMode:'abort'` 时零 listener 才 abort。累积路吞错、广播路拥有终态，这个「哪条路管终态」的划分是防重复/错误终态的关键。
- **对 CLWriting 的借鉴**：对话助手/写作链路的 SSE 可照搬「主进程持有流 + tee 广播/累积 + 每执行 ring buffer + 迟到回放 + 相位排序终态广播」；`signal 只取消广播路` 与「累积路自然排干」是我们「渲染进程崩溃不丢流」的实现蓝本。
- **成本与优先级**：中。批次 E。

### 2.8 steer 语义：入队 + 让出 + 续链的具体实现

- **代码位置**：AiStreamManager.ts enqueuePendingSteer（:1005-1035）、hasPendingSteer（:997-1001）、onExecutionDone（:1244-1291）、scheduleNextChatTurn（:1478-1493）、startNextChatTurn（:1500-1550）、dropPendingSteers（:1387-1397）
- **核心算法摘录**：

```ts
// AiStreamManager.ts:1003-1035 —— 入队，按流状态决定「立即续链 or 等让出」
enqueuePendingSteer(topicId, userMessageId, reasoningEffort?, fastMode?) {
  const status = this.activeStreams.get(topicId)?.status
  if (status && isLiveStatus(status)) { this.appendPendingSteer(...); return }   // live → 队列，step 边界让出
  if (status === 'aborted' || status === 'error') { logger.warn('dropping'); return } // 非干净终态 → 丢弃（行留可重发）
  this.appendPendingSteer(...)
  if (status !== 'awaiting-approval') this.scheduleNextChatTurn(topicId)       // done/无流 → 立即开续链
}

// :1273-1284 —— 让出：仅当「干净 done + 队列非空」才 chain（error/aborted/awaiting-approval 都不 chain）
const chatChaining = stream.status === 'done' && this.hasPendingSteer(topicId)
...
await this.broadcastExecutionDone(stream, exec, topicDone && !chaining)   // isTopicDone=false：bubble 收尾、topic 保持 busy
if (chatChaining) this.scheduleNextChatTurn(topicId)

// :1500-1550 —— 续链：消费队头、携带原 renderer listener、续链失败要显式收尾
private async startNextChatTurn(topicId) {
  if (this.isWriteQuiesced) { this.suppressedChatContinuationTopicIds.add(topicId); return }  // 备份静默期抑制，last disposal re-kick
  const queue = this.pendingSteers.get(topicId); const pending = queue?.[0]
  if (!pending) { this.pendingSteers.delete(topicId); return }
  const previous = this.activeStreams.get(topicId)
  if (previous && isLiveStatus(previous.status)) return   // 绝不驱逐未终态流（其终态 hook 还没跑）
  queue.shift(); if (queue.length === 0) this.pendingSteers.delete(topicId)
  const carried = previous ? [...previous.listeners.values()].filter(isRendererListener) : []
  if (previous) this.evictStream(topicId)
  try { await this.dispatch(carried[0] ?? nullStreamListener, { trigger: 'steer-continuation', ... }) }
  catch (error) { if (previous) this.failChatContinuation(previous, carried, serializeError(error)); return }
  for (const listener of carried.slice(1)) this.addListener(topicId, listener)   // 其余窗口经 buffer 回放 catch up
}
```

  - **让出的实现**：`hasPendingSteer` 被「steer-yield 停止条件」读取（:997-1001），运行中的 turn 在**下一个安全 step 边界**让出（注释 :991-995「mirrors agent runtime's enqueue + chain-next-turn」）。
  - **scheduleNextChatTurn 的 drain-dedup**（:1478-1493）：`startingNextChatTopicIds` 去重 + `queueMicrotask` 延后 + `inFlightChatContinuations` **同步**注册（调用方在 settling 的 loopPromise 里，drain 刚 await 完 loop 必须在下一次 collect 看到待启动的续链）。
  - **nullStreamListener**（:280-287）：主进程发起的续链无 live renderer 时用 `isAlive: () => false` 的哨兵，首次 dispatch 就被 scrub，流在后台跑完，窗口经状态缓存重新 attach。
  - **dropPendingSteers**（:1387-1397）：aborted/error 终态丢弃队列并 log——持久化的 user 行留在历史里作 dangling 可重发消息，表面化是 renderer 的职责。
- **设计理由与踩坑**：steer 是「入队 + 让出 + 续链」，不是中止重启；关键边界是「续链失败必须显式收尾」（否则 topic 永远 `streaming`、Stop 变 no-op、每个窗口空转，:1538-1545 注释）与「绝不驱逐未终态流」（strand 部分输出持久化）。
- **对 CLWriting 的借鉴**：写作链路里「用户在中途插入新指令」或「审查发现后打断起草」可用同一语义；`enqueuePendingSteer` 按 `status` 分流的四分支（live/done/awaiting-approval/aborted）是「打断-继续」状态机的现成模板。
- **成本与优先级**：中。批次 E/B。

### 2.9 SeedRunner 版本化 seeding：journal 记录格式

- **代码位置**：src/main/data/db/seeding/SeedRunner.ts（全 100 行）、hashObject.ts、seederRegistry.ts、types.d.ts；seeders/presetProviderSeeder.ts
- **核心数据结构摘录**：

```ts
// SeedRunner.ts:8-14 —— journal 键 + 版本结构
const SEED_KEY_PREFIX = 'seed:'
const BOOTSTRAP_MARKER_KEY = 'seedRunner:bootstrapCompleted'   // 首轮全成功后打标记
interface SeedJournal { version: string }

// SeedRunner.ts:19-63 —— 核心：journal.version === seeder.version 跳过；跑完 upsert journal
runAll(seeders: ISeeder[]): void {
  const journalMap = this.loadJournals(seeders.map(s => `${SEED_KEY_PREFIX}${s.name}`))
  const bootstrapCompleted = this.hasBootstrapCompleted()
  for (const seeder of seeders) {
    if (seeder.executionPolicy === 'bootstrap-only' && bootstrapCompleted) continue
    const journal = journalMap.get(`${SEED_KEY_PREFIX}${seeder.name}`)
    if (journal?.version === seeder.version) continue
    seeder.run(this.db)
    this.db.insert(appStateTable).values({ key, value: { version: seeder.version } })
      .onConflictDoUpdate({ target: appStateTable.key, set: { value: { version: seeder.version }, updatedAt: Date.now() } }).run()
  }
  if (!bootstrapCompleted) this.markBootstrapCompleted()
}
```

  - **ISeeder**（types.d.ts:10-26）：`name` + `version`（属性或 getter）+ `description` + `executionPolicy?('run-on-change'|'bootstrap-only')` + `run(db)`。注释：bootstrap-only = 只在整个 seeding 首轮全成功前的窗口跑，之后**永不**（新 release 加的 seeder 也不跑）。
  - **hashObject**（hashObject.ts:13-15）：`sha256(JSON.stringify(obj))` 全串，用于「从数据源自动生成 version」；注释给阈值——静态导入 ≤100KB 用（overhead <0.1ms），更大用数据源版本号或手写。
  - **PresetProviderSeeder**（presetProviderSeeder.ts:46-80）：`get version()` 返回 `this.getLoader().getProvidersVersion()`——即 **providers.json 的内容哈希**（第2.1节 的 contentVersion）。`run` 只 upsert 增量行（identity/display name/auth shell），连接配置（endpointConfigs/apiFeatures）**不持久化**、读时从 registry 解析——registry 更新到存量安装无需 reconcile（#17096 设计取舍，:9-15 注释）。
  - **seederRegistry.ts:12-20**：显式数组定执行顺序（FK 依赖：CherryAiDefaultModel 必须在 DefaultAssistant 前）。
- **设计理由与踩坑**：journal 记在 appState 表而不是单独表——复用 `key/value` 通用 KV，无需迁移；`onConflictDoUpdate` 幂等。bootstrap 标记的存在是为了「首启只跑一次的预设（如默认 assistant）与随版本升级的预设（如 provider 目录）分开」。
- **对 CLWriting 的借鉴**：我们表驱动 provider 数据若入库（或任何预设数据），直接套「`seed:<name>` 键 + 内容哈希 version + onConflictDoUpdate journal + bootstrap-only 标记」；表驱动数据版本用**内容哈希**而非日期戳（第2.1节 的坑）。
- **成本与优先级**：低。批次 A（A7）。

### 2.10 applyMigrations 的 FK 坑处理代码

- **代码位置**：src/main/data/db/applyMigrations.ts（全 57 行）；__tests__/applyMigrations.test.ts
- **核心代码摘录**：

```ts
// applyMigrations.ts:21-52 —— 在 migrator 事务外关 FK，迁移后跑 foreign_key_check
export function applyMigrations(db: DbType, migrationsFolder: string): void {
  const enforced = isForeignKeysEnforced(db)
  db.run(sql.raw('PRAGMA foreign_keys = OFF'))     // migrator 事务内是 no-op，必须在事务外
  try {
    migrate(db, { migrationsFolder })
  } finally {
    db.run(sql.raw(`PRAGMA foreign_keys = ${enforced ? 'ON' : 'OFF'}`))   // 恢复调用方原状
  }
  if (enforced) {
    const violations = db.all(sql.raw('PRAGMA foreign_key_check'))
    if (violations.length > 0) logger.error('Migration left dangling foreign key references', { violations })
  }
  for (const statement of CUSTOM_SQL_STATEMENTS) db.run(sql.raw(statement))  // FTS5/触发器幂等补跑
}
```

  - **坑的完整机制**（:22-29 注释）：SQLite 无法原地改约束，drizzle-kit 把约束/列类型变更编译成表重建（`CREATE __new_x → INSERT SELECT → DROP x → RENAME`），自带的 `PRAGMA foreign_keys=OFF` 守卫**从没生效**——drizzle migrator 把每条语句包进一个事务，SQLite 文档规定该 pragma 在事务内是 no-op，于是 DROP 触发每个子行的 ON DELETE 动作静默带走了数据。
  - **测试怎么写的**（applyMigrations.test.ts:99-123）：把生产迁移链拷进临时目录，手工往 journal 追加一条「重建表」迁移（drizzle-kit 为约束变更生成的原样形状），先插入父/子行，跑迁移后断言子行还在 + `foreign_key_check` 为空——**这是对「本坑已被修」的回归守卫**。还测了幂等性（:92-97）与「恢复调用方 foreign_keys 原状」（:125-134）。
  - **CUSTOM_SQL_STATEMENTS**（customSqls.ts）：Drizzle 管不了的 FTS5 虚表/触发器，全部幂等（IF NOT EXISTS / DROP IF EXISTS / rebuild-safe），每次迁移后补跑。
- **对 CLWriting 的借鉴**：我们若用 better-sqlite3+Drizzle，这函数可直接抄；现在若是纯 better-sqlite3 手写 SQL 迁移，则不存在该坑（事务内手写 FK 管理可控），但要记着「约束变更 → 重建表 → 级联删数据」这个陷阱。另可借鉴「迁移后 `PRAGMA foreign_key_check` + 报错不阻塞 boot」的「绝不静默」姿态。
- **成本与优先级**：低。批次 A（A8，将来迁移时抄）。

### 2.11 message.ts 消息树完整字段 + FTS5 稳定键

- **代码位置**：src/main/data/db/schemas/message.ts（全 220 行）
- **核心 schema 摘录**：

```ts
// message.ts:17-85
id: uuidPrimaryKeyOrdered()        // UUID v7（时间有序，大表顺序插入友好）
parentId: text()                   // 邻接表父引用（自引用 FK，cascade）
topicId: text().notNull().references(topicTable.id, { onDelete: 'cascade' })
role: text().notNull()             // 'user'|'assistant'|'system'|'root'
data: text({mode:'json'}).$type<MessageData>().notNull()   // AI SDK UIMessage.parts 内联 JSON
searchableText: text().notNull().default('')               // 由触发器填充（非 GENERATED 列）
status: text().notNull()           // 'pending'|'success'|'error'|'paused'
siblingsGroupId: integer().notNull().default(0)            // 兄弟分支分组（0 = 普通分支）
modelId: text().references(userModelTable.id, { onDelete: 'set null' })
messageSnapshot: text({mode:'json'}).$type<MessageSnapshot>()  // 发消息时模型快照
stats: text({mode:'json'}).$type<MessageStats>()               // token 用量/性能
compactionSummary: text()          // 覆盖到含本行的滚动摘要；读时不下发模型
ftsRowid: integer()                // FTS5 content_rowid 的稳定整数代理
// 约束与索引：
uniqueIndex('message_topic_root_uniq').on(topicId).where(parentId is null and deletedAt is null)  // 单根不变量 + O(1) root 查找
uniqueIndex('message_fts_rowid_uniq').on(ftsRowid)   // MAX+1 赋值变 O(log N)
check('message_role_check', role IN ('user','assistant','system','root'))
check('message_status_check', status IN ('pending','success','error','paused'))
check('message_root_parent_check', (role='root') = (parentId is null))  // root ⇔ parentId NULL，DB 级不变量
```

  - **FTS5 架构**（message.ts:106-195）：`message_fts` 是 external-content 虚表 `content='message', content_rowid='fts_rowid', tokenize='trigram'`；三个触发器 `message_ai`（INSERT 时赋 fts_rowid = `COALESCE(MAX(fts_rowid),0)+1` + 填 searchable_text + 插 FTS）、`message_ad`（DELETE 同步）、`message_au`（UPDATE OF data 时 delete+re-insert by fts_rowid）。**用稳定列而非隐式 rowid** 的原因（:148-158）：隐式 rowid 会被表重建（drizzle INSERT...SELECT）和 VACUUM 重排，静默 desync；`fts_rowid` 是真实列，穿越重建原样保留。
  - **searchableTextExpression**（:112-146）：从 `data.parts` 的 JSON 里 `json_each` + `json_extract` 抽出 text / data-code / data-translation / data-compact / data-error 的文本，`group_concat` 空格连接——纯 SQL 实现「消息哪些 part 参与搜索」。
  - **ftsRowid 可空的原因**（:49-53）：触发器在行插入后才填，NOT NULL 会在触发器跑之前拒绝行。
  - **messageSnapshot 与 compactionSummary 的行级持久化**：snapshot 是发消息时的模型快照；compactionSummary 是持久化压缩边界（覆盖到本行的滚动摘要），**读时从不下发模型**（:44-46 注释）。
- **设计理由与踩坑**：邻接表 + 分支分组支撑「重新生成/分支对话」；`siblingsGroupId` 让多分支共享一个「回复组」。root 不变量用 DB check 而非 service 层纪律（:80-83）。`message_status_idx` 是普通索引而非 partial（Drizzle 绑 `status = ?`，SQLite 匹配不到 partial 索引，:63-64 注释——很小的坑）。
- **对 CLWriting 的借鉴**：对话助手若要「重新生成/分支」，这张表是现成模板；`compactionSummary` 字段思路可用于自愈闭环的摘要记录（行级持久化，重启不丢）；`ftsRowid` 稳定键 + trigram 分词是「伏笔追踪全文检索」的现成蓝本（伏笔正文检索直接抄 FTS5 三触发器）。
- **成本与优先级**：中。批次 F（F4 消息树）。

---

## 三、与 8-14 旧报告的差异补充

旧报告覆盖了宏观骨架，以下本轮逐行核对后补出旧报告**没讲/讲浅**的细节：

1. **generate-catalog.ts 不止 3 个 JSON 产物，还有 3 个 .gen.ts 编译产物**（reasoning-families/server-tool-models/server-tool-constraints）——旧报告只提 data/*.json。这些「把运行期 regex 编译成精确 id 数组」的产物是「防宽泛前缀泄漏到新发现兄弟型号」的关键（generate-catalog.ts:113-116）。
2. **contentVersion 的完整契约**：旧报告只给了 :60-66 的哈希代码，没讲两点——(a) 哈希前必须 **sortKeys**（否则相同内容不同 version）；(b) **为何不用日期戳**（同一天重生成改内容但日期不变 → seeder 静默永不跑，generate-catalog.ts:60-65）。这两点才是「内容哈希」设计的原因。
3. **canonicalize.ts 三件套**（canonOf / prefixHit / splitOverrideWireId）旧报告完全没提。尤其 `splitOverrideWireId`（不写 apiModelId 的 override 自动 split 成 canonical key + wire id）是 provider-models 能工作的底层机制。
4. **findOverride 的 9 个索引 + self-variant 规则**：旧报告 CS-3 只说「三套索引」，实际 override 侧有 7 个 key 索引 + 1 个 per-provider 数组；「`apiModelId === modelId` 的 self 变体总是抢占 canonical slot，且顺序无关」这条规则（registry-loader.ts:176-191）与「精确 apiModelId 必须先于归一化 fallback」（:241-246）都是旧报告没有的。
5. **归一化规则的「不做」清单**：`HYPHEN_VARIANT_SUFFIXES` 特意不含 `-medium`（真 tier 名）、`COMMON_AGGREGATOR_PREFIXES` 特意不含 `mm-`（先 expand 成 minimax- 再剥，不然孤儿化）、日期剥离必须校验合法月份/日期——这些「特意不做什么」的注释是整套规则的精华，旧报告一个都没提。
6. **IPC 的变参条件元组**（`InputFor<R> extends void ? [] : [input: InputFor<R>]`，renderer ipcApi.ts:36）——旧报告讲了类型推导但没讲 void input 不需要传参的这条实用细节。
7. **IPC output 用 `z.custom<T>()`、router 永不 parse output**——「output 由可信 main 构造，parse 是纯浪费」这个取舍旧报告没提（schemas/ai.ts:42-50）。
8. **流式的 ring buffer**（maxBufferChunks=10_000、maxDeltaBytes=16_384、split/merge delta、审批 pending 时暂停驱逐）与 **dispatchToListeners 相位排序**（persistence 先、cleanup 后、persistence 失败抑制通知）——旧报告只提 tee 与 fan-out 概念。
9. **steer 的 nullStreamListener 哨兵、write-quiesce 抑制 + last-disposal re-kick、续链失败显式收尾**（topic 否则永远 streaming）——旧报告 CS-15 只写了「入队+让出+续链」六个字。
10. **SeedRunner 的 bootstrap-only 与 journal 在 appState 表**（`seedRunner:bootstrapCompleted` 标记区分「首启一次」与「随版本升级」）——旧报告 CS-18 只说了 journal 记在 appState。
11. **message.ts 的 DB 级不变量**：`check('message_root_parent_check', (role='root') = (parentId is null))`、单根 partial uniqueIndex、`ftsRowid` UNIQUE 使 `MAX+1` 赋值 O(log N)、searchableText 用触发器而非 GENERATED 列——旧报告 CS-6 只列了字段名。
12. **Drizzle FK 坑的完整机制**：旧报告说了「migrator 事务内 PRAGMA 是 no-op」，但没讲「约束变更被编译成表重建、自带 OFF 守卫从没生效」这条因果链（applyMigrations.ts:22-29），以及测试是**手工往 journal 追加重建表迁移**来回归的（applyMigrations.test.ts:99-123）。
13. **applyMigrations 的「恢复调用方原状」+「迁移后 foreign_key_check 只报错不阻塞」**——旧报告没提恢复逻辑（它是 restore/test-harness 共用路径，硬失败不可恢复）。

## 四、不值得抄的部分

1. **reasoning wire 操作级编码体系**（`ReasoningWireOperationSchema` 的 target/value/source 三元组、effort 映射表、budget policy）：只为把「供应商怪癖」做成数据。旧报告已判不值得，本轮确认代码复杂度比旧报告更重（schemas/reasoningWire.ts 有 ~40 个 wire target 常量、3 种 value source、budget policy 分支），CLWriting 的写作链路没有推理旋钮需求，**只取「能力/参数支持/线上编码」三张表的划分思想**即可。
2. **30s 空闲 TTL 缓存**（RegistryLoader）：为 2 万行 models.json + 3 万行 provider-models.json 设计；我们表驱动数据量小，懒加载 + 常驻即可，TTL 是负资产。
3. **300+ provider / 60+ creator 的目录规模**：归一化规则表（COMMON_AGGREGATOR_PREFIXES 40+ 前缀、BEDROCK 跨厂商 ARN 剥离）是为「host/gateway 重命名空间」生态设计的；我们只有少数服务商，取「分层与守卫」思想、规则表裁剪到自己的命名空间即可。
4. **写时推导 adapterFamily 的三级链 + 运行期只读**：对我们是过度设计；直接表驱动一列就够。
5. **FTS5 三触发器 + searchableTextExpression 的四段 JSON 抽取 SQL**：若我们不索引消息/正文全文，直接跳过；若做伏笔检索，只取「external-content + content_rowid 稳定键 + 三触发器」骨架。
6. **validateSender / WindowManager 窗口信任链**：我们有自己已有的 IPC 信任模型；`Object.hasOwn` 防注入是唯一值得单独抄的一行。

## 五、给综合报告的 Top-N 建议摘要

1. **目录生成管线三件套**（源码 → 生成物 + 内容哈希版本 → CI 双向校验）：配合已完成的表驱动重构补闭环，版本哈希避免「同天重生成 seeder 不跑」坑。**中成本**，批次 D。
2. **IPC schema 单点声明 + senderId-only context + `Object.hasOwn` 防注入**：长期收益最大的一项；`Object.hasOwn` 一行可先加。**中成本**，批次 E。
3. **模型能力三层探测 + 归一化索引**（精确 → 保留尺寸 → 尺寸无关 + 宁缺勿错）：替换/补充已退役的 probeModelCaps。**中成本**，批次 D。
4. **消息树 + 邻接表 + compactionSummary + ftsRowid**（分支对话/自愈闭环摘要/伏笔 FTS 的存储基础）：**中成本**，批次 F。
5. **steer「入队+让出+续链」四分支状态机**与 **tee 广播/累积 + ring buffer 回放**：对话助手打断-继续与渲染进程崩溃不丢流。**中成本**，批次 E/B。

> 注：本报告聚焦 cherry-studio 六个专题（provider 目录生成、ProviderExtension 注册表、能力三层探测、IPC schema、流式架构、SeedRunner/Drizzle FK/消息树），deepseek-harness 的对应深化研读在同目录另两份报告中（dsh-会话与编排、dsh-上下文与防护）。
