# CLWriting 现状盘点（2026-08-15）

- 日期：2026-08-15
- 研读对象：CLWriting 自身 src/ 代码（工作目录即 CLWriting-Main 根），落点定位用相对项目根路径 + file:line
- 研读方式：read/grep 直读源码，本轮已逐行读完：self-heal.ts 全量、chat.ts 全量、runner.ts 全量、model-quirks.ts 全量、store.ts 全量、prepare.ts 全量、materials.ts 全量、main.ts IPC 区、manifest.ts 全量、check/runner.ts 头部、review/run.ts 回收区、responses-adapter.ts 头部、git/exec.ts 全量、fake-provider.ts 全量、w1-acceptance.test.ts 全量、chat.test.ts 头部、store.test.ts、model-quirks.test.ts、w1-chat-tier.test.ts；未在本轮逐一重读（标注「未在本轮核实」）：cache/schema.ts 逐列、desktop/preload.ts 逐行、foreshadow.ts 中段、document/snapshot.ts 中段
- 关联：`Dev/Main/Archive/参考项目深化研读与借鉴吸收-2026-08-15.md`（已吸收 8-14 宏观条目版；8-14 原档已删）
- 归档：2026-08-24 移入 Archive/（原 04-调研/；现状基线已历六十轮评审演进，仅供 2026-08-15 时点考古）。

---

## 一、总体现状

CLWriting 的核心写作链路按「上下文 → 起草 → 审查 → 润色 → 提交」五层组织，逐层落点与成熟度如下：

| 层 | 实现位置 | 关键机制 | 成熟度 |
|---|---|---|---|
| 上下文 | src/process/prepare.ts（备料+预算闸）、src/process/materials.ts（RAG 接缝）、src/process/assemble.ts（账本/近况聚合） | 段落化材料 + 弹性降档裁剪 + token 估算（0.6 token/字） | 高（已落地预算闸 #12） |
| 起草 | src/process/draft-pipeline.ts buildDraftPrompt、src/ai/orchestrate/self-heal.ts 首稿 | 细纲/备料/章纲/世界观 slice(0,1200) 拼 user prompt；tool_use 契约 | 高 |
| 审查 | src/check/runner.ts（机检 11 项）、src/review/run.ts（三审）、src/studio/server/api/review.ts | 红/黄分级；S1-S4；三级 tier（full/sequential/combined） | 高 |
| 润色 | src/process/rewrite-prompt.ts buildRewritePrompt、self-heal 重写循环 | 红项[必须]/黄项[建议]区分；local/whole 分支；LCS 行级 diff | 高 |
| 提交 | src/document/finalize.ts finalizeRevision、src/document/manifest.ts | 内容指纹 + manifest 定稿基线（去 git 版本系统） | 高 |

**自愈闭环**（src/ai/orchestrate/self-heal.ts，566 行）：单章/批量双路径（P2-3），每章「首稿→机检→重写→全绿/触顶」，重试判定在 src/process/retry.ts evaluateRetry（红/黄两级，maxAttempts=3，**无退避表、无 LLM 错误码分类**）。provider 层重试（429/5xx 退避）在 src/ai/runner.ts runTask（BACKOFF_MS=[1000,2000,4000]，MAX_RETRIES=3，可中断 sleep）。

**provider 表驱动**（src/ai/provider/）：model-quirks.ts 静态表（七系列 × 11 能力维度）已完全取代旧的 probeModelCaps 模型级探测；probe.ts 只做服务级 connected/streaming 探测；store.ts 有 vault 信封加密 + 400 降级记忆 + 档位回落（creative/assistant/chat）。

**prompt 组装**：模板字符串 + 运行时文件读取拼接，硬编码在 TS 里（非资源化），无预算控制（上下文层有段落级预算闸，但 prompt 组装本身无分层优先级契约）。

**流式**：driver/cc.ts 广播式事件总线（主进程不拥有 AI 生成流，生成是 fire-and-forget + SSE 回流）；chat.ts 有 MAX_AGENT_TURNS=5、AGENT_DEADLINE_MS=30min、CONFIRM_TIMEOUT_MS=2min、MAX_HISTORY_TURNS=10、MAX_HISTORY_BOOKS=8（LRU）。

**IPC**（src/desktop/main.ts registerIpc + preload.ts）：约 15 个 desktop:* channel，**无 schema 声明、无类型推导**，handler 内逐个手动 typeof 校验。

**伏笔**（src/document/foreshadow.ts，363 行）：设定/伏笔/*.md fm 解析 + 正文 grep 首末命中 + 风险阈值（高=30/中=60/低=100 章）+ 幂等迁移。

**版本/快照**（src/document/snapshot.ts→version.ts、revision.ts、finalize.ts）：sha256 字节指纹（Revision = sha256:<hex>），独立文件全量快照（.版本/ ULID id），非 diff 链；**不支持 replace 遮蔽语义**（版本是独立文件列表，无「模型可见 ⟺ 已记录」的遮蔽层）；pinned 永久保留；DEFAULT_VERSION_POLICY={maxDays:14,maxCount:30,throttleMinutes:5}。

**缓存**（src/cache/）：SQLite 5 表（leads/lead_history/chapters/summaries/meta），rebuild 原子事务 + sync 中英 key 映射，仅作精准读取加速（账本永不走 RAG，走精准读取）。

---

## 二、关键落点明细

以下每条按「参考项目条目 → CLWriting 现状落点 + 判断」。判断三档：**已有**（可直接对标）、**部分有**（机制存在但缺关键能力）、**没有**（缺位）。

### 2.1 自愈/重试体系

1. **重试次数 + 打回逻辑** — src/process/retry.ts:29-60 evaluateRetry(report, attempt, maxAttempts=3)：红项>0 → retry；attempt>=maxAttempts → escalate。**已有**（核心三态 pass/retry/escalate 齐备，测试 test/process/retry.test.ts 覆盖 attempt 0/1/2 retry、3 escalate）。
2. **退避表** — src/ai/runner.ts:245 await sleep(BACKOFF_MS[attempt]!, ctrl.signal)，BACKOFF_MS=[1000,2000,4000]（runner.ts:9）。**部分有**：退避只覆盖 429/5xx 可重试错误（GenError.retryable），自愈打回本身（红项）无退避——即「AI 产出质量不行」的重写轮次没有退避，直接连打。参考项目 A4/A5（连续相同调用提醒、错误码分类）落点在此，**为没有**。
3. **错误码分类** — src/ai/runner.ts:252 错误统一包 GEN_FAIL；runTask 只区分 RETRYABLE/ABORTED/TIMEOUT_TOTAL/GEN_FAIL 四类。**部分有**：有粗粒度错误码（trace.errCode 落盘），但无参考项目级别的细粒度 LLM 错误码分类表。A5 为**部分有**。
4. **可中断 sleep** — src/ai/runner.ts sleep(ms, signal)（runner.ts 尾部），退避中 abort 立即生效。**已有**。
5. **整体超时** — src/ai/runner.ts:211-213 timeoutMs（档位可覆盖，默认 DEFAULT_TIMEOUT_MS=600_000）→ abort ctrl，catch 区分 TIMEOUT_TOTAL vs ABORTED。**已有**。
6. **首字节超时** — src/ai/gen.ts withFirstByteTimeout，FIRST_BYTE_TIMEOUT_MS=60_000。**已有**。
7. **流式重试防重复产出** — src/ai/runner.ts:135,244 onReset 回调（重试前推 reset 事件清前端缓冲，B-1）。**已有**。
8. **重试可见性（前端 warning）** — src/ai/runner.ts:136,243 onRetry → self-heal 侧 src/ai/orchestrate/self-heal.ts:496-500 emit warning「AI 响应异常，第 N 次重试中…」。**已有**（Bug C 修复，注释明示不再静默卡死）。

### 2.2 provider 表驱动

9. **模型能力静态表** — src/ai/provider/model-quirks.ts:125-259 quirksFor(model) switch(detectFamily)：七系列（claude/gpt/grok/deepseek/glm/kimi/unknown）× 11 维（toolUse/toolChoiceMode/effortMap/maxOutputTokens/maxTokensKey/reasoningEffort/thinkingWithEffort/trimStop/emitStreamOptions/structuredMode/anthropicEffortWire/parallelControl/echoReasoning）。**已有**（表驱动重构 第6.3节 已落地，注释附官方文档出处，测试 test/ai/provider/model-quirks.test.ts 全维度断言）。
10. **探测退役** — src/ai/runner.ts:108-110 注释明确「modelCaps 探测退役——能力由静态表判定」；src/ai/provider/probe.ts 只保留服务级 probeCapabilities（connected/streaming）。**已有**（旧报告 D3 说的「probeModelCaps 已退役」——现状确认已退役，改静态表）。
11. **服务级探测** — src/ai/provider/probe.ts probeCapabilities 30s 超时。**已有**。
12. **凭据加密存储** — src/ai/provider/store.ts:177-226 saveProviders：vault 信封加密（HKDF→KEK→DEK→AES-GCM）+ 剥离明文 + chmod 0600 + D7 写前备份 + 原子写（atomicWriteFile fsync）+ 半迁移收敛。**已有**（S4 九条验收判据在 store.test.ts 逐条覆盖）。
13. **400 降级记忆** — src/ai/provider/store.ts:234-240 registerDegradedPersist/persistDegraded（适配器深处 mutate 不回缓存，runner 注册落盘函数转发）。**已有**。
14. **档位回落** — src/ai/provider/store.ts:257-266 tierFromStore：assistant/chat 未配或 model 空 → 回落 creative/currentModel。**已有**（w1-chat-tier.test.ts 覆盖四种回落情形）。
15. **responses 线 400 降级** — src/ai/provider/responses-adapter.ts:120-130 text.format 结构化输出 400 → 降级为无 structured 重试。**已有**。

### 2.3 上下文/材料组装

16. **备料预算闸（源头限流）** — src/process/prepare.ts:96-115 段级组装 + applyBudgetTrim（弹性优先级 5=RAG→4=非本章预警→3=远期摘要→2=文风样章→1.5=前章正文结尾→1=近章结尾摘要，两轮：先降档再整段移除，刚需永不砍）。**已有**（#12 预算闸，比参考项目 A2「压缩预算钳制」更早落地且是段落级）。
17. **token 粗估** — src/process/prepare.ts:54-57 estimateTokens = ceil(len*0.6)（中文约 0.6 token/字，注释附 #12 第 5 节出处）。**已有**。
18. **段落边界截断** — src/process/prepare.ts:62-70 tailByParagraph（按双换行截断不切半句；降档 1500→500 字）。**已有**（边界处理贴合正文语义，中文场景无 grapheme 级保护需求）。
19. **RAG 接缝** — src/process/materials.ts:140-202 prepareMaterials：未配 RAG 直接 prepare（行为逐字节不变）；已配 → await recall → renderRecallHits 精准读正文切片 → prepare(ragRecallText)。**已有**（M7 #37 R1 真正接入；账本永不走 RAG 红线；降级诚实——召回失败回落精准读取不崩主路径）。
20. **降级留痕** — src/process/materials.ts ragNote/styleNote（G3：声明场景却查无样章 → 提示 learn 补）。**已有**。

### 2.4 审查/润色

21. **机检 11 项** — src/check/runner.ts:73-110 runAllChecks：红 4 + 黄 7，按数据存在性条件开关（有布线→账本三检+成长线+专名/信息差；有 config.short→短篇专属；通用项恒跑）。**已有**（#10 机检规则 spec 落地）。
22. **byproducts（审查上下文富化）** — src/check/types.ts CheckReport 含 byproducts: leadChanges/infoLeakCandidates/newNames/pieceListChecks；三审端点把 byproducts + 账本清单 + 正文 draftBody 喂给 AI（review.ts 端点）。**已有**（比参考项目「工具结果修剪」更进一步——CLWriting 是把机检副产品作为三审输入）。
23. **三审 tier 确定性契约** — src/review/contract.ts selectReviewTier/buildReviewTasks/isBlockingCategory（ledger/reversal/payoff/safety 必阻断）、SEVERITY_RANK。**已有**。
24. **三审降级诚实** — src/review/run.ts:204-276 collectReviewIssues：缺视角/坏 JSON 不崩，记 missing_lenses/bad_entries，ok=false 表示审稿单不成立。**已有**。
25. **润色指令红黄优先级** — src/ai/orchestrate/self-heal.ts:238-241 [必须] 红项 + [建议] 黄项（REWRITE_INSTRUCTION 常量在 self-heal.ts:39）。**已有**（W1 测试断言必须/建议同时存在）。
26. **LCS 行级 diff** — src/process/rewrite-prompt.ts lineDiff（LCS DP），local/whole 分支。**已有**。

### 2.5 流式 / chat agent

27. **agent 轮次上限 + 全局超时** — src/ai/orchestrate/chat.ts MAX_AGENT_TURNS=5、AGENT_DEADLINE_MS=30*60_000、CONFIRM_TIMEOUT_MS=2*60_000、MAX_HISTORY_TURNS=10、MAX_HISTORY_BOOKS=8（LRU 内存历史）。**已有**。
28. **工具确认闸（pending Map）** — src/ai/orchestrate/chat.ts TOOL_RISK 分类（check_chapter readonly / write_chapter write），write 类先 emit chat_tool_pending → waitConfirm（CONFIRM_TIMEOUT）→ 超时取消。**已有**。
29. **工具执行 race 保护** — src/ai/orchestrate/chat.ts:133-162 write_chapter 前查 isSelfHealRunning(bookName)（本书在自动写章则拒）；chat 中断时显式桥接 abortSelfHeal（onAbort，self-heal 独立 ctrl）。**已有**（ctrl 换新时先 abort 旧，driver/cc.ts 同款模式）。
30. **escalate 不算失败** — src/ai/orchestrate/chat.ts:154-158 B-P1-6：escalate 时章已生成落盘，ok=true 防 AI 误判失败重复写章。**已有**（注释明示踩坑）。
31. **历史消毒** — src/ai/prompts/chat.ts sanitizeHistory：空 content 剔除、连续同 role 插互补占位、孤儿 tool_use/tool_result 处理、首条必须 user。**已有**。
32. **SSE 事件总线** — src/driver/cc.ts：广播式，每 stream 消费者独立队列、pre 暂存 preTaken 标志、interrupt abort ctrl。**已有**。注意：**主进程不拥有 AI 生成流**（旧报告 E1「主进程拥有流」落点为**部分有**——driver 只是进度回流通道，生成是 fire-and-forget + SSE 端点 src/studio/server/api/stream.ts MAX_SSE_PER_BOOK=5）。
33. **LLM 错误码/调用约定** — 无专门错误码表。**没有**（A5 落点）。

### 2.6 IPC

34. **IPC 无 schema** — src/desktop/main.ts:368-469 registerIpc：约 15 个 desktop:* channel（open-library/switch-library/get-recent/get-current/show-in-folder/open-book-dir/get-system-fonts/open-shelf/open-book/open-library-window/open-library-dir/context-menu/context-menu-select + navigate 事件），handler 内逐个手动 typeof 校验 + 路径穿越防护（relative startsWith ..、symlink realpath 二次校验）。**部分有**：安全校验扎实，但**无 schema 声明、无类型推导**（preload.ts contextBridge 只暴露 invoke+on 通用壳）。E2 落点为**没有**（schema 声明）但有安全兜底。
35. **workdir-store 纯数据层** — src/desktop/workdir-store.ts：MAX_RECENT=5、parseStore/setCurrent/filterValidRecent/serializeStore，零 Electron 依赖可单测。**已有**（参考项目「纯函数分离」同款，test 直接测）。

### 2.7 伏笔/版本/缓存

36. **伏笔足迹** — src/document/foreshadow.ts：ForeshadowEntry（file/标题/状态/埋设章号/回收章号/重要性/关联词/摘要）、readForeshadows、scanForeshadowTrails（正文 grep 首末命中，风险阈值 高=30/中=60/低=100 章）、migrateLegacyForeshadows（幂等）。**已有**（test/document/foreshadow.test.ts 覆盖命中/阈值边界/迁移幂等/同名标题不覆盖）。
37. **sha256 指纹** — src/document/revision.ts（16 行）：Revision = sha256:<hex>、computeRevision=hashFile。**已有**。
38. **全量快照非 diff** — src/document/version.ts writeVersion（ULID id、原子写、去重/节流 throttleMinutes=5、FINE_WINDOW_MS=2h、分层保留、pinned 永久保留）。**部分有**：是独立文件全量快照（可回滚），但**无 replace 遮蔽语义**——「模型可见 ⟺ 已记录」的遮蔽层（F1 事件溯源核心）**没有**；版本是「一次快照一个文件」，不是 append-only 事件日志。F1 落点为**没有**（但 .版本/ + git 旁路 ref src/git/ai-track.ts refs/clwriting/ai/<docId>/<ulid> blob ref 提供部分版本/回滚能力）。
39. **定稿基线** — src/document/manifest.ts:23-28,104-110 ManifestEntry.finalizedRevision/finalizedAt；writeManifest 原子重写整文件（jsonl 幂等合并）。**已有**（去 git 版本系统的核心：内容指纹 + manifest 定稿基线，src/document/finalize.ts finalizeRevision 幂等写 pinned + 更新 manifest）。
40. **缓存 SQLite** — src/cache/schema.ts 5 表 DDL + rebuild 原子事务 + sync 中英 key 映射。**已有**（仅作精准读取加速，不做 RAG 语义检索；RAG 是独立 src/rag/ 模块）。

---

## 三、与综合报告的差异核对

1. **D3 模型能力探测已退役**：旧报告 D3 提「模型级三层探测（替代/补充已退役的 probeModelCaps）」——现状确认 probeModelCaps **已退役**，能力判定完全改由 model-quirks.ts 静态表承担（runner.ts:108-110 注释为证），服务级探测保留（probe.ts）。综合报告 D3 表述应更新为「静态表已落地，服务级探测保留，模型级探测不再需要」。
2. **E1 主进程拥有流**：旧报告 E1 建议「主进程拥有流」——现状是主进程**不拥有** AI 生成流，driver/cc.ts 只是广播式事件总线（每消费者独立队列），生成是 fire-and-forget + SSE 回流。此条落点为「部分有」（驱动结构在，但架构取向不同，非缺陷）。
3. **E2 IPC schema**：无 schema 声明、无类型推导，**没有**（但安全校验扎实，见 2.6-34）。
4. **A2 压缩预算钳制**：CLWriting 已有段落级预算闸（prepare.ts #12），比参考项目更早落地且粒度更细（段落降档 + 整段移除 + 头部留痕），综合报告 A2 可降级为「已对标，无需重做」。
5. **A4 连续相同调用提醒 / A5 错误码分类**：均**没有**（自愈打回无退避、无细粒度错误码分类），是真正可吸收的增量。
6. **F1 事件溯源 replace 遮蔽**：**没有**——版本系统是独立文件全量快照 + manifest 定稿基线，无 append-only 事件日志 / 遮蔽层。综合报告 F1 若坚持要，需要重做存储层，成本高。
7. **prompt 预算控制**：上下文层有段落级预算（prepare.ts），但 **prompt 组装本身**（模板 + 运行时拼接，硬编码在 TS）无分层优先级契约、无 token 预算控制。C1-C3 落点**没有**（除段落级外）。

---

## 四、未在本轮核实（落地前必须复核原文）

- src/cache/schema.ts 5 表逐列字段（本轮只读了 DDL 总体，未逐列核对）。
- src/desktop/preload.ts 逐行（contextBridge 暴露面细节，仅确认 invoke+on 通用壳）。
- src/document/foreshadow.ts 中段（scanForeshadowTrails 的 grep 正则实现细节，阈值常量已核）。
- src/document/snapshot.ts 中段（快照文件命名/保留细节，版本策略常量已核）。
- src/ai/trace.ts / trace-stats.ts / calls.ts / rule-hits.ts / author-signal.ts 的测试文件未逐一读。

---

## 五、给综合报告的 Top-N 建议摘要

1. **自愈打回加退避 + 错误码分类（A4/A5）**：evaluateRetry 目前红项连打无退避、错误只分 RETRYABLE/GEN_FAIL 两级。可抄参考项目：红项连续命中 → 指数退避 + 相同错误码去重提醒。成本低（改 src/process/retry.ts + src/ai/runner.ts 的 error code 映射）。
2. **IPC schema 声明（E2）**：15 个 channel 手动 typeof 校验，建议引入 channel→schema 映射表 + 渲染端类型推导。成本中（新增类型层，不动安全校验）。
3. **版本系统补 replace 遮蔽（F1）**：当前全量快照可回滚但无「模型可见 ⟺ 已记录」遮蔽层，若要完整事件溯源需重做存储层。成本高（架构级，建议作为可选远期项）。
4. **prompt 资源化 + token 预算**：prompt 硬编码在 TS，建议抽资源 + 组装层 token 预算（借鉴 prepare.ts 段落级闸的既有模式）。成本中。
5. **上下文预算闸（A2）已对标**：prepare.ts 段落级预算闸已落地，综合报告可标注「已覆盖，无需重做」。
