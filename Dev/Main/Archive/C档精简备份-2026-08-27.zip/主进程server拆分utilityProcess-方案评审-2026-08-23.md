# 主进程 server 拆分 utilityProcess 执行方案 — 方案评审（开工前）

- 日期：2026-08-23
- 评审对象：`02-执行/主进程server拆分utilityProcess-执行方案-2026-08-22.md`（状态：已拍板可开工，未开工）
- 评审基线：HEAD `372c8cb`（dev，工作树干净）；代码核对覆盖 `src/desktop/**`、`src/studio/server/index.ts`、`src/studio/web-next/src/api/client.ts` + `composables/useSse.ts` + `useHeartbeat.ts`、`src/log/index.ts`、`tsup.config.ts`、`electron-builder.yml`、`test/desktop/main.test.ts`、`test/e2e/global-setup.ts` + `release-smoke.spec.ts`、装机 `node_modules/electron/electron.d.ts`（Electron 42 API 口径）。
- 性质：**方案文档评审**（非代码复审轮）——发现项的处置是修订方案文档/补充微决策，P1/P2 修订回填进方案后才算收口；不涉代码改动。
- 收口：**已收口（2026-08-23 同日）**——§五 8 条修订全量回填执行方案（S→落点映射见 §七 收口记录），总览（阶段 22 行/文档地图/决策状态表）与任务清单批次 K 同步更新（S-6 三处口径统一）；方案维持已拍板可开工、未开工；U-6 按建议 A 默认执行（作者可否决）。
- 结论：**骨架成立、工程判断总体成熟（进程图/握手/退出联动/e2e 不受影响/回滚廉价等论断核验属实），但「崩溃自动重启 + 前端零改动恢复」这一核心卖点在现有前端契约下按方案原文实现必然失效（S-1/S-2 两个隐藏契约未识别），且改动面清单落后于 8-23 两轮复审后的代码现状（S-4/S-6）。开工前必须修订。**

---

## 一、发现总表

| # | 级别 | 一句话 | 处置建议 |
|---|---|---|---|
| S-1 | 高危 | utility 重启必须复用原端口——前端全部同源相对路径，换端口后渲染进程永远连不回；方案未写 | §3.3/§3.4 补一句（重启 fork 显式 `--port <上次实际端口>`），验收门 3 补断言 |
| S-2 | 高危 | studioToken 每次 startServer 重新生成、前端只在挂载时取一次且无 401 重取——重启后写请求/SSE/心跳全部永久 401，「恢复回绿」不成立 | 新增微决策 U-6（token 注入持久化 / 重启后整窗 reload / 前端 401 重取 三选一，附建议），§1.3/§3.4 承诺口径随选型改写 |
| S-3 | 中危 | U-5「child 不自写 JSONL」与「`src/studio/server/**` 零改动」红线冲突：initLogging 在 startServer 内部无条件落盘；落地机制未指定，改动面清单缺 `src/log/index.ts`；且 §3.5 的转发写法会产生 JSON 套 JSON | 明确选型（建议 src/log 加 stdout-only 模式）、改动面补文件、转发承载方式改为原行落盘或解析 level/tag 再发 |
| S-4 | 中危 | 改动面清单缺 `src/desktop/bootstrap-runner.ts`（8-23 O-4 落地）——runner 的「重试关旧 server」注入语义在拆分后必须换轨到 serverManager；§2.1 走读（「main.ts bootstrap 334-424 行」）已过时 | 刷新 §2.1；§四 main.ts 行补 runner 接线；server-manager 设计补「重试=kill 旧 child」 |
| S-5 | 中危 | exit 事件双语义未互斥：before-quit 的 kill 兜底同样触发 exit，若监听无条件退避重启，退出途中会 fork 新 child（孤儿进程，直接打挂验收门 4）；「ready 一次性」措辞对重启轮次不成立 | §3.4 补「shutdownStarted 后 exit 不触发重启」；握手状态机按「每 fork 一轮」建模 |
| S-6 | 中危 | 引擎名写错：全仓零 better-sqlite3 引用，存储是 Node 内置 `node:sqlite`——R-1 的「ABI 不匹配」对策口径失准，真实首验项是 node:sqlite 在 utility 进程的可用性；总览阶段 22 行与第九节批次 K 同句复述，按文档操作链三处同步 | 三处文档改引擎名与首验口径（隔离收益论述本身成立，仅换名） |
| S-7 | 中危 | utility 进程网络栈口径未核：Electron ForkOptions 文档注明 utility 网络请求默认走「system network context」，server 的 LLM provider 出呼（fetch）在系统代理环境下的行为可能与 main 内嵌态不等价——威胁验收门 1 的行为等价红线 | 批 U1 增实测项（开代理环境 provider 出呼对照），或 R 表登记 |
| S-8 | 低危 | needsWelcome 态（workDir=null）fork 参数未覆盖：现状 startServer({workDir:null}) 合法（welcome 页由 server 托管），§3.3 参数表写死 `--dir <abs>` | §3.3 补「--dir 可缺省=welcome 态」；批 U1 手动过一遍 welcome 建库链路 |
| S-9 | 低危 | 退避重启计数器无复位窗口——长期运行偶发崩溃累计到 3 会误弹对话框 | 建议「ready 后稳定运行 N 分钟清零」一句进 U-2 |
| S-10 | 低危 | serverOnline 仅进书后有心跳——书架页/welcome 页 utility 崩溃对用户不可见（信号初始 true 不翻转） | §2.2「天然感知断连」表述如实化为「书内」，U3 演练口径同步；改心跳挂 App 层破前端红线，仅登记不做 |
| S-11 | 低危 | §2.3 e2e 表述不精确：主套件 39 用例的 server 是 global-setup 进程内 import startServer（`test/e2e/global-setup.ts`），只有 release-smoke 2 用例真跑 `dist/desktop/server-main.js` | 措辞修正（结论不变且更稳） |
| S-12 | 低危 | ForkOptions 未指定 serviceName——getAppMetrics 单列的可辨识名（ProcessMetric.name）缺失，账目目标（§1.3 第 3 条）落空一半 | server-manager fork 参数补 serviceName（如 `studio-server`） |
| S-13 | 低危 | 资产快照漂移：main.test.ts 现 24 用例（方案写 20）；main.ts 行号 ±2（startServer 实为 369、listenPort 242-251） | 修订时顺手对齐，不影响判断 |

## 二、高危详述

### S-1 重启必须复用原端口（方案一句话可修，但不写必翻车）

前端与 server 的全部通信都是**同源相对路径**，不含任何绝对基址：

- `src/studio/web-next/src/api/client.ts:70` `apiFetch` 直接 `fetch(path)`（path 形如 `/api/...`）；
- `src/studio/web-next/src/composables/useSse.ts:31-32` 生产态 `base = ''`（仅 dev 直连 7878），EventSource 浏览器自动重连同樣只认原 URL；
- 心跳 `useHeartbeat.ts:17` 同为相对路径 POST。

渲染进程页面从 `http://127.0.0.1:<port>` 加载那一刻起，origin 就固化了；没有任何 `desktop:*` IPC channel 会把「新端口」告诉渲染层（12 个 channel 已逐一核对，全部是字体/菜单/书库管理类，无 server URL 传递）。

方案 §3.3 参数表只定义了首启形态（`--port 0`，实际端口走 ready 回传），§3.4 时序 3 的退避重启未定义 fork 参数——按默认同套参数实现即 `--port 0` 换新端口，重启后渲染进程的心跳/SSE/fetch 全部打到死端口：**「前端 serverOnline 心跳失败自动置灰，恢复自动回绿」「重连 UI 近零成本」（§1.3 目标）完全不成立**。

修法（main 侧一句话）：serverManager 记录首启 ready 回传的实际端口，重启 fork 显式 `--port <该端口>`。Node `net` listen 默认 SO_REUSEADDR，child 进程死亡后 socket 释放、立即重绑无障碍。连带两个细则需写进时序 3：

- 重启钉端口失败的 EADDRINUSE 属瞬态，应**继续退避重试**，不得走时序 2 的「对话框 + app.quit()」——时序 2 仅适用于首次启动；
- 验收门 3 现文只写「serverOnline 灰→绿恢复」，该信号恰好会被 S-2 卡死（见下），演练还需补「写请求恢复」断言（如进书后手动保存一次成功）才算闭合。

### S-2 studioToken 跨重启失效——「零改动恢复」的第二个隐藏契约，需作者拍板

token 链路事实：

- 服务端：`src/studio/server/index.ts:140` `const studioToken = randomUUID()`——**每次 startServer 一个新值**；写方法与 SSE 均以它为闸（index.ts:294 写请求 header 校验；`api/stream.ts:219` SSE query 校验）。
- 前端：`client.ts:29-54` `boot()` **应用挂载前调一次** `/api/boot` 取 token 存模块级变量；`apiFetch` 无 401 拦截重取；`client.ts:32` 注释自认失败后果「应用以离线态启动（写请求将持续 401）」。头注 O-10（第十三轮）还显式声明了「每个渲染进程一份」的多窗口约束。

即使 S-1 修好（端口复用），utility 重启 = 新进程 = 新 token，渲染进程内存里的旧 token 全部失效：

- 所有写请求（POST/PUT/DELETE）永久 401——**包括心跳本身**（POST，自动注入 token），`serverOnline` 永远灰；
- SSE 携旧 token query 被 stream 路由拒绝，重连全部 401，进 60s 退避死循环；
- GET 不校验 token 照常工作——「读活着、写全死」的半死态比整页崩溃更难排查。

可选对策（三选一，建议新增微决策 **U-6** 由作者拍板）：

| 选项 | 代价 | 红线影响 |
|---|---|---|
| **A. token 由 main 生成/持久化，经 fork 参数注入 child；startServer 增加可选 `studioToken` 注入口** | server/index.ts 签名 +1 可选参数 | 动 `src/studio/server/**`（红线需显式修订为「+1 可选参数」）；安全口径不降级——books.ts boot 路由头注（ee-P2-12 拍板）已明确「token 不承诺防本机进程」，防的是远端网页驱动，网页读不了本地文件 |
| **B. 重启成功后 main 对全部窗口 `webContents.reload()`（主窗/书架/书库三窗）** | 整页重载，未保存键入可能丢一个自动保存节拍内的内容；书架/书库窗口状态重置 | main 侧 only，前端/server 零改动；语义对齐既有 dd-P3 渲染进程崩溃重载自愈的容忍口径 |
| C. 前端 401 时重跑 boot() 重取 token | 前端改动 + 重试语义散布 | 破「前端零改动」红线，不推荐 |

**建议 A**：唯一能同时保住「窗口与编辑器界面状态全程存续」（§3.4 时序 3 的加粗承诺）与「前端零改动」的选项，且改动量最小（一个可选参数）。选 B 则 §3.4 时序 3 的「界面状态全程存续」必须如实改写。无论选哪个，§1.3 目标第 1 条与 §2.2 useHeartbeat 行的「天然感知断连/恢复，零改动」表述都要按选型修订。

## 三、中危详述

### S-3 日志单写者（U-5）与 server 零改动红线的冲突未识别

`startServer` 内部无条件 `initLogging({ logsDir: join(userDataPath,'logs'), mirrorConsoleLog })`（`src/studio/server/index.ts:143-146`）。child 拿到 `--user-data` 后必然自写 JSONL——与 main 双进程同写 `userData/logs/app-YYYYMMDD.jsonl`，且 child 若按 §3.3 传 `--mirror-console`，同一条日志会被记两遍（child 自写一行 + stdout 转发 main 再落一行）。U-5「child 不自写 JSONL、log 模块走 stdout 输出」需要一条方案没有写的落地路径：

- **建议**：`src/log/index.ts` 加 stdout-only 模式（如 env `CLW_LOG_STDOUT=1` 时 emit 直写 stdout、不排队落盘），server-utility 入口最早已设——src/log 不在「零改动」红线清单内，但**必须补进 §四 改动面清单**；
- 不建议 server-utility 在 startServer 之后再 initLogging 覆盖（窗口期已落盘行 + 依赖调用顺序的脆弱设计）；改 startServer 签名则破红线。
- §3.5「逐行转发 `log.info('server-proc', line)`」会产生 JSON 套 JSON（child stdout 本就是 `{ts,level,tag,msg}` 行）——转发侧应原行落盘（绕过 emit 序列化）或解析 level/tag 再 emit，写进 server-manager 设计。

### S-4 改动面落后于代码现状：bootstrap-runner.ts 缺席

本方案 8-22 立项，8-23 第十三轮 O-4 把 bootstrap 生命周期三段守卫抽成了 `src/desktop/bootstrap-runner.ts`（`getStudioServer/setStudioServer` 注入 + 「重试前关旧 server」L-3/R-14 语义 + shuttingDown 直通），main.ts 只剩接线。拆分后：

- runner 的「关旧 server」必须换轨为「kill 旧 child」（经 serverManager），deps 语义重定义；
- §2.1 启动链走读写「main.ts bootstrap，334-424 行」已不能反映现状（bootstrap 主体虽仍在 main.ts，行号亦漂移），§四 的 main.ts 行也未提 runner 接线。

属文档时效问题而非设计错误，但改动面清单是执行依据，**开工前必须刷新**（同批顺手销 S-13 行号漂移）。

### S-5 exit 双语义与握手轮次

- before-quit 的 `child.kill()` 强杀兜底同样触发 child `exit` 事件——若 exit 监听无条件退避重启，app 退出途中会 fork 出新 child（孤儿进程/退出被拖长），恰好打挂验收门 4。需在 §3.4 明确「shutdownStarted 后 exit 不触发重启」（server-manager 内部状态门）。
- §3.2「ready 一次性」对单 child 成立，但重启后每个新 child 都会再发一次 ready——握手状态机需按「每 fork 一轮」建模（port 也随轮次更新/复用），建议测试用例覆盖「两轮 fork 各收到 ready」。

### S-6 存储引擎名失实：node:sqlite，非 better-sqlite3

全仓（src/ + scripts/ + package.json）零 `better-sqlite3` 引用；依赖仅 `@anthropic-ai/sdk / font-list / openai` 三件，SQLite 走 Node 内置 `node:sqlite`（`src/cache/schema.ts`、`src/check/growth.ts`、`src/ai/tools/status.ts` 等；tsup 配置头注还专门处理了 `node:` 前缀保留）。影响：

- R-1 的「ABI 不匹配」对策推理不适用——没有第三方 native 模块，electron-builder.yml 也无需 asarUnpack（现状自洽）；
- 真实首验项变为「node:sqlite 在 utility 进程可用性」（同一 Electron 内嵌 Node，理论无障碍；顺带记档实验性告警口径）；
- §1.2 痛点 1「native 段错误带崩 main」的论述换名后依然成立（node:sqlite 同为进程内 native 实现），隔离动机不受影响。

同步义务：总览「三、实施顺序」阶段 22 行与 8-15 第九节批次 K 均复述了「better-sqlite3 native 首验」，按文档操作链**三处一起改**。

### S-7 utility 进程网络栈口径未列验证

装机 `electron.d.ts` ForkOptions.`session` 字段文档原文：「By default, network requests from the utility process will use the system network context which does not have HTTP cache support」——utility 进程网络请求默认走系统网络上下文，与 main 进程内嵌态（Node 直连栈）是否行为等价未经验证。本项目对代理环境有前科（`main.ts:277` dev 态 renderer 显式 setProxy direct 防 clash/surge buffer SSE；useSse 头注同因）。server 的入呼（127.0.0.1 listen）预计不受影响，**出呼面（LLM provider HTTP、font-list 之外的系统命令不涉）**在系统代理开启环境下的行为需实测对照——否则验收门 1「行为等价红线」存在未检验的洞。建议批 U1 验收补一条（或 R 表加 R-7 登记）。

## 四、核验通过项（方案论断属实，开工可依赖）

| 方案论断 | 核验 |
|---|---|
| §2.1「12 个 desktop:* channel」 | main.ts:434-565 实数 12 个（open-library/switch-library/get-recent/get-current/show-in-folder/open-book-dir/get-system-fonts/open-shelf/open-book/open-library-window/open-library-dir/context-menu），全部只碰 fs/store/shell，无 server 模块直调 |
| main 对 server 模块唯一直调 = startServer + setInitialBook | ✓（拆分迁移面封闭） |
| §2.1 退出链描述（shutdownStudio：每书 abortSelfHeal/abortChat + waitSettled + waitBackgroundTasks + server.close，双 1.5s） | graceful-shutdown.ts 逐行属实（签名实为 `(getWorkDir, server, opts)`，workDir 是回调查——修订时顺手校准） |
| §2.2 server-main 资产（:35 EADDRINUSE 中文文案、SIGINT/SIGTERM 2s 强退） | ✓ |
| §2.2 useHeartbeat（20s POST /heartbeat、serverOnline 全局信号） | ✓（但见 S-10 书架页盲区） |
| §2.2 kk-P2-8 mock electron 假件驱动 | ✓（用例数漂移见 S-13） |
| §2.2 render-process-gone 自愈（dd-P3） | main.ts:412-415 ✓ |
| §2.3 e2e 不受影响 | 结论成立（表述修正见 S-11）：主套件 global-setup 进程内起 server，release-smoke 2 用例跑编译产物 server-main.js |
| §四 tsup entry 增补可行 | ✓ 同 config（external electron、outDir dist/desktop、P-13 预清不冲突） |
| electron-builder `files: dist/**/*` 自动含新入口；check:packaging 门不枚举 dist 文件 | electron-builder.yml + scripts/check-packaging.mjs 核对 ✓，新入口不触门 |
| Electron 42 API 面子 | typings 核对：`utilityProcess.fork(modulePath, args?, options?)` ✓；`child.postMessage(message, transfer?: MessagePortMain[])` 传 port2 ✓；`exit` 事件带 code ✓；`kill()` ✓；`env` 缺省 `process.env`（§3.3「默认继承」论断正确）✓；`stdio` 缺省 **inherit**——方案显式 `pipe` 正确且必要 ✓ |
| §3.3 staticDir child 自派生（dirname/本文件/../web） | 与 server-main.ts:27 同款；asar 内 fs 补丁直读有 CC-P1-7 resourcesRoot 同构先例 ✓ |
| 上游三提交（cff3432/2b5a4af/1f7c2fd）与总览阶段 22 / 第九节批次 K 挂接 | 全部在位 ✓ |
| relaunch()/second-instance/--book 链路不涉 server URL（全走前端导航/IPC/重启） | ✓ S-1 的「main 侧可修」前提由此成立 |
| CSP 注入在 main session 层（onHeadersReceived），与 server 进程归属无关 | ✓ |

## 五、修订清单（收口门）

方案文档需回填的修订（按节归位，P1/P2 全办结 + P3 顺手项一并落）：

1. §1.3/§2.2/§3.4：「前端零改动天然恢复」按 U-6 选型改写；时序 3 补端口复用与「重启 EADDRINUSE 走退避」。
2. §3.3：参数表补「--dir 可缺省=welcome 态」（S-8）、「重启复用端口」（S-1）、serviceName（S-12）。
3. §3.5/§四：日志落地选型 + src/log/index.ts 入改动面（S-3）；bootstrap-runner.ts 入改动面 + §2.1 走读刷新（S-4）。
4. §3.4：shutdownStarted 后 exit 不触发重启；握手按 fork 轮次建模（S-5）。
5. §1.2/R-1/批 U1：引擎名改 node:sqlite + 首验口径（S-6）；总览阶段 22 行 + 第九节批次 K 同步。
6. 批 U1 验收/R 表：utility 网络栈（系统代理环境 provider 出呼对照）（S-7）；U-2 补计数复位窗口（S-9）；U3 演练补「写请求恢复」断言（S-1 连带）。
7. 微决策表：新增 U-6（token 对策，附建议 A）；U-2 附复位窗口。
8. §2.2/§2.3 措辞：serverOnline 书内口径（S-10）、e2e 表述（S-11）、用例数/行号对齐（S-13）。

修订完成后本报告收口（评审链口径：P1/P2 修复回填通过才收口；本评审的「修复」= 方案文档修订）。

## 六、收口记录（2026-08-23 同日）

§五 8 条修订全量回填执行方案，逐项落点（方案 §十 修订记录同款口径）：

| 发现 | 落点 |
|---|---|
| S-1 端口复用 | 方案 §3.1 端口/token 契约注 + §3.3 参数表（重启 `--port <原端口>`、瞬态 EADDRINUSE 走退避）+ §3.4 时序 3 + 批 U3/验收 3 断言（端口不变 + 写请求恢复） |
| S-2 token | 微决策 **U-6（建议 A）** + §1.3 目标改写 + §2.3 唯一红线豁免注 + §3.3 参数行 + §四 server-manager/server index.ts 两行 + 验收 1/3 |
| S-3 日志 | §3.5 重写（src/log stdout-only + main 解析重发、不 JSON 套 JSON）+ §四 src/log 与 test/log 行 + R-4 对策更新 + 批 U2 验收 |
| S-4 bootstrap-runner | §2.1 走读刷新（runner 存在/行号校准/退出链签名）+ §四 新增行 + main.ts 行接线注 |
| S-5 exit 互斥 | §3.2「每 fork 一轮」建模 + §3.4 时序 3/4 状态门 + §四 测试行 + 批 U2 用例 + 验收 4/6 |
| S-6 引擎名 | 方案 §1.1/§1.2/R-1/批 U1 统一 node:sqlite 口径；总览阶段 22 行（实施顺序）+ 文档地图 + 决策状态表 + 任务清单批次 K 同步（三处一致） |
| S-7 网络栈 | R-7 新增 + 批 U1 开代理环境实测（连通性/延迟/流式完整性） |
| S-8 welcome 态 | §3.3 --dir 可缺省 + §四 server-boot 行 + 批 U1 验收（建库链路） |
| S-9 计数复位 | U-2 附「ready 后稳定 5 分钟清零」+ 批 U2 用例 |
| S-10 书内口径 | §1.3/§2.2 如实化 + §九 登记（不做，作者可取舍） |
| S-11 e2e 表述 | §2.3 校准 |
| S-12 serviceName | §3.3 参数行 + §四 server-manager 行 + 验收 5 |
| S-13 快照对齐 | §2.1 行号 + §2.2 用例数（24） |

方案头部已挂修订记录（日期行 + 状态行 U1-U6）；**方案维持「已拍板可开工，未开工」**——批 U0-U4 开工时以修订版为准。

## 七、评审方法备忘

主评审逐文件亲读 + 装机 Electron typings 原文核对，未使用子代理（对象是单份方案文档 + 其引用的 ~15 个代码触点，主评审直接核验成本更低且全链可追溯）。所有发现均给出可点击定位；S-1/S-2 的结论链条（相对路径 → origin 固化；randomUUID → boot 一次性 → 无 401 重取）每环均有源码行号锚定。
