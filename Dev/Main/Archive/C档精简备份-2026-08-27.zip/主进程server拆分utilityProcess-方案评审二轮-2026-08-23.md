# 执行方案评审：《主进程server拆分utilityProcess-执行方案-2026-08-22.md》（二轮）

- 日期：2026-08-23（同日二轮）
- 对象：`02-执行/主进程server拆分utilityProcess-执行方案-2026-08-22.md` **一轮评审（S-1~S-13）回填后的修订版**
- 基线：HEAD 372c8cb 工作树（一轮修订为纯文档批，不涉代码）
- 评审人：作者（对一轮回填质量做二轮复核）；主评审逐条亲验代码事实后落档执行（§四 附记）
- 结论：**可开工维持**——新发现中危 2 + 低危 4（F-1~F-6），均为文档级修订，不推翻已拍板决策；作者优先级「开工前先销 F-1/F-2，F-3~F-6 随批顺手销」，实际处置为同日一次性全销（§五）
- 状态：**已收口（2026-08-23 同日）**

## 总评

一轮 S-1~S-13 回填后方案总体成立：恢复链两个契约（端口复用/token 稳定）、改动面补全（bootstrap-runner/src/log）、exit-重启互斥、node:sqlite 口径、utility 网络栈验证均已落档。二轮聚焦回填质量本身，新发现中危 2 + 低危 4：F-2 为握手机制前后矛盾（§3.2 与 §四 各写一套互斥传输，照文实施有歧义），F-1 为用例数账实漂移（自一轮 S-13 继承），其余为转发/短路/口径细节。均不推翻拍板，修订后开工。

## 一、核验通过项（作者复核 10 项，落档时按要点归纳）

1. main.ts 行号锚点（startServer:369 / setInitialBook:34、362-365 / listenPort:242-251 / bootstrap 336-425）与现码一致；
2. graceful-shutdown 签名与双 1.5s 超时口径属实；
3. Electron typings 缺省值核对无误（stdio 缺省 'inherit'、env 缺省 = process.env、serviceName → ProcessMetric.name、ParentPort 默认双向通道）；
4. 一轮回填后执行方案与总览（阶段 22 行/文档地图/决策状态表）、任务清单批次 K、双 README 索引同步一致；
5. U-6 唯一红线豁免表述与 server 零改动红线不冲突；批 U0-U4 与改动面清单对应完整；
6. §3.3 参数表与 §3.4 四时序互洽；验收清单与微决策/风险表交叉引用无悬空。

## 二、发现

### F-1【中危·账实漂移】「24 用例」三处失实，实际 21

- 位置：§2.2 资产表（行 74）/ §四 main.test.ts 行（行 155）/ §十 S-13（行 250）；
- 证据：`npx vitest run test/desktop/main.test.ts` → **21 passed (21)**；`it(` 精确计 21；
- 来源链：一轮评审报告 S-13 判定「现 24」即误（回填时未复核直接进正本）；历史锚点 5775f69 首次接线 19 例，演进 19→21，从未到 24；
- 处置：三处 24→21（已销）。

### F-2【中危·设计不一致】握手机制两套互斥：§3.2 MessageChannelMain vs §四 parentPort

- §3.2 写 `new MessageChannelMain()` + port2 传给 child / port1 留守；§四 server-manager 行写 parentPort 握手——两套互斥传输机制并存，照文实施产生歧义；
- Electron 42 typings ParentPort（electron.d.ts:10710-10727）提供默认双向通道，MessageChannelMain 仪式非必需；
- 处置（建议统一 parentPort，已销）：§3.2 重写为 main 侧 `child.on('message')` / `child.postMessage` ↔ child 侧 `process.parentPort.on('message')` / `postMessage`；§四 server-manager 行与任务清单 K1 同步。

### F-3【中危·实现缺口】§3.5 转发丢 err 且 ts 被重写

- `log[level](tag, msg)` 重发丢 `log.error` 第三参 err——server 侧错误对象/堆栈在转发层丢失，与「排障口径不变」矛盾；ts 亦被 main 收行时刻重写；
- 处置（已销）：`log[level](tag, msg, err)` 透传（行内无 err 字段不传第三参）；ts 漂移可接受（stdio 实时转发），原始时刻考古走行内原文兜底路径。

### F-4【低危】stdout-only 未短路 initLogging 的文件系统副作用

- §3.5 原文只写「logsDir 不被消费」（只挡 emit）；src/log/index.ts:102-108 的 mkdir + 7 天清理在 initLogging 无条件执行，child 每次 fork 仍有副作用（与 main 双清同一 logs 目录）；
- 处置（已销）：短路上移 initLogging 层——不设 logsDir / 不 mkdir / 不 cleanup。

### F-5【低危·建议】token 复用机制显式化

- §四/§3.3 未写明持久化 token 的读取时机；建议「启动读入内存一次，fork 一律复用内存值」（免每次 fork 读盘，亦消除会话中途 token 文件损坏→重启换代 token 的窄边）；
- 处置（已销）：§3.3 token 行 + §四 server-manager 行 + 任务清单 K1 显式化。

### F-6【低危·口径】「401」应为「403」

- 服务端对无/错 token 统一 **403 FORBIDDEN**：写闸 `src/studio/server/index.ts:296`、SSE 闸 `src/studio/server/api/stream.ts:220`；「401」口径沿自 client.ts:24/32 注释（该注释自身不精确，描述的是「写请求持续失败」非服务端状态码）；
- 处置（已销）：执行方案六处 401→403（§2.2×2 / §3.1 / U-6×3）。

## 三、结论

- **可开工维持**：F-1~F-6 均为文档级修订，不推翻 2026-08-22 A 方案拍板与微决策默认；
- 优先级：F-1/F-2 开工前先销（账实/实施歧义）；F-3/F-4 随批 U2（写 §3.5/src/log 时顺手）；F-5/F-6 措辞/实现细节随批；
- 核心需改文件：`Dev/Main/02-执行/主进程server拆分utilityProcess-执行方案-2026-08-22.md`（§2.2/§四/§十 的 24→21；§3.2 握手机制统一；§3.5 err 透传；§四 token 读入内存）。

## 四、落档与核验附记（主评审补）

- 本文系作者 2026-08-23 会话内提交的二轮复核意见落档：六项发现的判定、证据、处置建议与结论主旨逐项保留，结构整理为本文；§一 核验通过项按作者复核要点归纳。
- 主评审对全部发现的代码事实逐条亲验，全部成立：F-1 `npx vitest run test/desktop/main.test.ts` → **21 passed (21)**，误计根因实证（一轮宽匹配 grep 把 3 行 `emit(`（122/236/561 行）计入 24），git 锚点 `5775f69` 提交信息「首次接线 19 例」；F-6 `server/index.ts:296` 与 `stream.ts:220` 均 `replyError(res, 403, 'FORBIDDEN', ...)`；F-3/F-4 与 `src/log/index.ts` 现码（`log.error` 第三参 / initLogging 无条件 mkdir+cleanup）核对属实；F-2 typings ParentPort 接口核对属实。
- **两处归因更正（如实记档）**：①F-2 的矛盾并非一轮回填「引入」——8-22 初稿 §3.2（MessageChannelMain 标题 + port2 正文）与 §四 server-manager 行（parentPort 握手）即两套并存，一轮评审漏检、回填原样保留，二轮抓出；发现本身完全成立。②F-1 的「24」始于一轮 S-13 自身误计（主评审计数方法错误——宽匹配 grep 未排除 `emit(` 等 `it(` 子串），回填环节未复核放大为三处；此后计数一律以 vitest 实跑为准。

## 五、收口记录（2026-08-23 同日）

- F-1 → 执行方案 §2.2 / §四 / §十 S-13 行三处 24→21；
- F-2 → §3.2 重写（parentPort 默认消息通道，弃 MessageChannelMain 端口转移）+ §四 server-manager 行 + 任务清单 K1；
- F-3 → §3.5 `log[level](tag, msg, err)` err 透传 + ts 重记口径注明；
- F-4 → §3.5 + §四 src/log 行 initLogging 层短路；
- F-5 → §3.3 + §四 server-manager 行 + 任务清单 K1「启动读入内存一次，fork 一律复用内存值」；
- F-6 → §2.2×2 / §3.1 / U-6×3 六处 401→403；
- 索引同步：执行方案头部 + §十增记、任务清单批次 K（表头/K1）、总览（文档地图行 / 1.3 评审表增行 + 一轮行归档注 / 阶段 22 行附注）、01-评审 README（一轮随二轮开评归档，Archive 现 34 篇）、Dev/Main README（01-评审行 / Archive 计数 / 变更记录）；
- 方案状态维持：**已拍板可开工，未开工**（批 U0-U4 以二轮修订版为准）。
