# cherry-studio 请求组装调研与适配对比

日期：2026-08-14
状态：调研完成；effort 值域裁剪已定稿（第四节）并于 2026-08-14 实施完毕
（typecheck + 1439 测试全过，待真 Key 实测 kimi/grok）；sanitize 已定性为前瞻储备
参考项目：`Dev/参考项目/cherry-studio`（2026-08-14 重新拉取远程后核对）
归档：2026-08-24 移入 Archive/（原 04-调研/；D 批次已落地，effort 裁剪已实施；「待真 Key 实测」余项由阶段 13 中转真机验证承载）。

## 背景

打磨 API 请求与 AI 工作流之间的适配。cherry-studio 是成熟的多厂家 AI
chat/agent 工具，其请求组装与厂家适配机制有借鉴价值。调研方式：并行
两路（cherry-studio 源码 / CLWriting `src/ai`），主会话汇总对比。

---

## 一、cherry-studio 调研结论

### 请求组装链路（6 层，单点组装）

| 层 | 位置 | 职责 |
|---|---|---|
| 入口 | `src/main/ai/AiService.ts:503/647` | 收 IPC，分流 chat/agent-session |
| 单点组装 | `runtime/aiSdk/params/buildAgentParams.ts:125` | endpoint→sdkConfig→tools→caps→reasoning→features，产出 BuiltAgentParams |
| 消息构建 | `packages/aiCore/.../modelMessageAdapter.ts:56` | ModelMessage↔IR 无损往返 + 边界消毒 + 截断/压缩 |
| 参数注入 | `buildAgentParams.ts:493` | standardParams + providerOptions（按命名空间）+ features 贡献 |
| 协议映射 | `provider/endpoint.ts:93` | adapterFamily → AI SDK provider 查表 |
| 发送 | `runtime/aiSdk/Agent.ts:25` | AI SDK ToolLoopAgent → 官方 provider → HTTP |

关键设计：**chat 与 agent 共用一条组装路径，最后才分流**。

### 厂家适配机制（全声明式，三层数据）

- **注册表声明层**：`packages/provider-registry/src/providers/*.ts`，每厂
  ~30 行 `defineProvider` 声明 endpointConfigs / apiFeatures / overrides
- **请求层适配器**：`RequestFeature`（`params/feature.ts:7`）——applies
  门控 + 三贡献点（模型中间件 / 循环钩子 / stopConditions）+ 错误隔离
- **reasoning wire 声明**：`schemas/reasoningWire.ts:104` 闭集
  `{off/auto/effort} → operations[{target,value}]` 表 + 纯函数解释器

具体厂家差异例：
- DeepSeek：effort 自降 xhigh→max；`arrayContent:false`；V4 wire 联合注入
  thinking.type + reasoning_effort
- Anthropic：budget < max_tokens 时整段 omit 约束
- OVMS：`applies: 有 MCP 工具时` 给用户消息追加 `/no_think`
- cherryin：fetch 包装拦截请求体，`tools:[]` 时有 tool_choice 则删除

### agent 工具机制（tools / tool_choice 实现）

1. **工具注入**：客户端经 IPC 传入工具定义**但不带 execute**（结构化克隆
   安全考虑，`types/requests.ts:50`）→ `buildAgentParams.ts:396` 取
   clientTools → resolveTools 注册表筛选 → `Agent.ts:66`
   `wrapToolsWithExecutionHooks` 包装执行钩子 → `agentSettings.tools`
2. **toolChoice 策略**：默认不设（AI SDK 默认 auto，模型自由决定）；
   客户端 `callOverrides.toolChoice` 显式指定才透传（`buildAgentParams.ts:604`）
3. **多轮循环**：ToolLoopAgent 每轮 doGenerate 带 tools + toolChoice；
   循环终止靠 `stopWhen` 步数硬上限 `stepCountIs(N)`
   （`toolLoopTermination.ts:39`），不靠 toolChoice 强制；
   另有 `repairToolCall` 修工具调用错误
4. **sanitize 定位（评审修正：cherryin 一家特例，非通用防线）**：全仓核实
   无通用请求体清洗层——「tools:[] 时删 tool_choice」仅存在于 cherryin 的
   OpenAI 兼容 chat fetch 包装（`ai-sdk-provider/cherryin-provider.ts:125-141`）；
   通用 `customFetch` 不改 body，Ark/DashScope/Codex/Grok CLI 的 body 改写
   均为 per-provider 一次性补丁

### toolChoice 枚举对照

| 强度 | Anthropic | OpenAI | 含义 |
|---|---|---|---|
| 最弱 | none | none | 禁止调工具 |
| 自由 | auto | auto | 模型自己决定，可调可不调 |
| 强制 | **any** | **required** | 必须调工具，不指定哪个 |
| 最强 | {type:'tool',name} | {type:'function',name} | 必须调指定的工具 |

- `auto` 两协议语义一致（自由选择，可能不调工具）；`any` 是 Anthropic
  特有枚举，对应 OpenAI 的 `required`——同一档语义的跨协议叫法
- CLWriting 内部统一意图值（any/tool/auto），adapter 按协议翻译
  （openai-adapter 把 'any' → 'required'）
- 哲学差异：cherry 聊天场景默认 auto（爱调不调）；CLWriting 写作场景
  默认 any/required（结构化产出是产品刚需，auto 会允许模型直接吐正文
  导致流程断裂）——方向相反但各自合理

### 可借鉴清单

| 模式 | 做法 | 评价 |
|---|---|---|
| adapterFamily 协议映射 | 声明 adapterFamily，运行时查表 | 协议选型集中一处 |
| RequestFeature 适配器 | applies 门控 + 三贡献点 + 错误隔离 | 厂家怪癖与主链路解耦 |
| reasoning wire 声明 | 闭集 target/value 操作表 + 纯函数解释器 | 参数映射从硬编码变数据 |
| caps 能力位 | apiFeatures 布尔位 | 小差异不再写 if |
| 消息 IR 无损往返 | 截断/压缩不破坏 reasoning part | 上下文管理安全 |
| 请求体 sanitize | cherryin 特例：fetch 包装删 tools:[]+tool_choice | 一家特例非通用防线；仅多轮循环引入时参考 |
| provider 实例缓存 | settings hash + LRU + in-flight 去重 | 避免每请求重建 |

---

## 二、CLWriting 现状

### 请求链路（6 层，编排层面向抽象）

1. **编排层**：`orchestrate/chat.ts`、`self-heal.ts` 等 8 条链路统一走
   TaskSpec 声明（system/tool/mock/genMode 五件套），只拿 ModelProvider
2. **统一执行层**：`runner.ts:118 runTask`——provider+tier 解析、整体超时
   10min、429/5xx 退避重试 3 次、abort 优先、trace+记账
3. **生成层**：`gen.ts`——逐事件收集 text/reasoning/tool/usage、requireTool
   意图翻译、60s chunk 超时
4. **Provider 分派**：`probe.ts:20` 按 conf.protocol 选三适配器
5. **适配器 toParams**：anthropic / openai / responses 三 adapter
6. **HTTP**：SDK 直发

### 表驱动机制

`model-quirks.ts`：detectFamily 按前缀判系列；quirksFor 返回 FamilyQuirks
——能力维度（toolUse/toolChoiceMode/effortValues/effortMap/maxOutputTokens）
+ 线格式维度（maxTokensKey/reasoningEffort/trimStop/emitStreamOptions 等）。
unknown 保守省略一切可选参数。

### 痛点核对（t 轮 7 项 + 历史 4 项全清零）

| 痛点 | 状态 | 位置 |
|---|---|---|
| toolChoice 硬编码 DeepSeek 400 | 已修 | quirks 表 required 项 |
| 空 system 发出 | 已修 | 三 adapter 守卫 |
| max_tokens 8192 硬编码 | 已修（仅兜底） | anthropic-adapter.ts:66/:91 表值优先 |
| reasoning-only 空消息 | 已修 | prompts/chat.ts:122-127 |
| buildChatContext 历史污染 | 已修 | chat.ts:237-240 |
| chat 无 caps 守卫 | 已修 | gen.ts 静态表守卫 |
| Responses 不发 effort | 已修 | responses-adapter.ts:75-78 |
| effort/tool 顺序 | 已修 | responses-adapter.ts:46-60 |
| SSE 单消费者竞态 | 已修 | useSse.ts:19-21 |
| gen.ts 超时挂死 | 已修 | gen.ts:65-70 void return |
| runChat 锁泄漏 409 | 已修 | chat.ts:369-371 |

职责划分：重试/中断/超时集中 runner 层；400 降级（剥 structured +
modelCaps 记忆）在 adapter 内；回滚在工作流层。

---

## 三、对比结论

### 同构点（CLWriting 已对齐）

| 维度 | cherry | CLWriting |
|---|---|---|
| 组装收敛 | 单点 buildAgentParams | TaskSpec 五件套 |
| 厂家差异 | 注册表 + RequestFeature | FamilyQuirks 表驱动 |
| 协议映射 | adapterFamily 查表 | conf.protocol 分派 |
| 编排层 | Agent 封装 | 只面向 ModelProvider |

### 差异与适配问题候选

1. **发送前 sanitize（评审修正：非实质差异）**：初稿误把 cherryin 特例
   读成 cherry 通用防线（见 第一节第 4 条）。CLWriting 单轮 TaskSpec 架构无
   此动机场景（requireTool 任务 tools 恒非空，spec.ts:109），表驱动 +
   400 降级已覆盖；待未来引入多轮工具循环时配套补防线。
2. **动态怪癖无处安放**（前瞻储备）：cherry 的 RequestFeature 支持动态
   门控；CLWriting quirks 全静态。当前无此类需求，YAGNI 暂不实施。
3. **provider 实例缓存**（核验：无需照搬）：CLWriting 每请求 new SDK
   client，构造是纯配置包装、无 IO 无解密，成本可忽略。
4. **effort 值域裁剪**（已核实定稿，2026-08-14）：结论修正了原印象——
   cherry 并非「自动降档」，而是 wire 查表默认透传 + 极少数有意改写。
   详见第四节。

### 总体判断

t 轮 7 项 API400 链路痛点已全部清零，架构与 cherry 同构，**不存在大缺口、
无待实施差异项**。值得记录的是 2（feature 化扩展点）与 sanitize 预案
（并入 第五节多轮循环储备项）。

---

## 四、effort 值域裁剪核实（2026-08-14 定稿）

逐厂家官方文档核实 effort 档位 + cherry 机制源码对照，方案定稿。

### 官方值域核实（调研日期 2026-08-14）

| 厂家 | 官方值域 | 默认 | 官方折叠行为 | 出处 |
|---|---|---|---|---|
| Claude | low/medium/high/xhigh/max | high | 五档全收 | docs.anthropic.com |
| OpenAI gpt/o | none/minimal/low/medium/high/xhigh/max | medium | 七档全收（模型级差异见 guide） | openai-openapi spec ReasoningEffort |
| GLM 5.2+ | max/xhigh/high/medium/low/minimal/none | max | low/medium→high、xhigh→max、none/minimal→不思考 | docs.bigmodel.cn concept-param |
| DeepSeek v4 | low/high/max | high | medium/xhigh→high | api-docs.deepseek.com thinking_mode |
| Kimi K3 | low/high/max | max | 未声明 | platform.kimi.ai chat/completions |
| Grok 4.6 | low/medium/high/xhigh | high | 4.5 收 xhigh 当 high（不 400） | docs.x.ai reasoning guide |

### cherry 机制（源码对照，2026-08-14 新版）

三层：UI 词汇表（`controls`/`supportedEfforts` 限制可选档，新版由
controls 派生）→ nearest-match（模型切换沿强度阶梯找最近档）→ wire
查表 `effortMap?.[selection] ?? selection`（无命中透传）。

effortMap 两类用途：①auto 模式翻译（auto→具体档，auto 非强度）
②极少数有意改写（有注释背书）。deepseek 特例：官方折 xhigh→high，
cherry 有意发 max 直达顶档（注释："leaving max as the only way to
reach the top level"）。GLM/Kimi/Grok/OpenAI 全部纯透传——OpenAI
原生协议甚至零 reasoning 声明。

### CLWriting 学歪点

- trimEffort 把 deepseek 特例泛化成通用规则（波及 kimi/glm）
- effortMap 语义偏移：cherry 是协议无关 wire 查表，CLWriting 只接
  anthropic 线
- effortValues 想做 UI 词汇表但零消费（死字段）

### 定稿方案（用户拍板）

原则：官方映射是服务端行为，客户端不预演；全透传 + deepseek 保留 cherry
双映射（评审修正：cherry v4EffortMap 实为四项 minimal→low / low→low /
medium→high / xhigh→max，其中仅 xhigh→max 是有注释背书的有意改写；
CLWriting 词汇表无 minimal，取 medium→high、xhigh→max 两项）。

范围决策（2026-08-14 用户拍板）：只适配现役模型，旧模型（如
gpt-5.1-codex-max 之前的 OpenAI 模型对 xhigh/max 报 400）不在范围——
与「不做模型白名单」分发原则一致，越界报错用户可见，不预演映射兜底。

| 厂家 | wire 行为 |
|---|---|
| claude / gpt / glm / kimi / grok | 五档透传 |
| deepseek | medium→high、xhigh→max（特例） |

改动清单（2026-08-14 已实施，测试全绿）：
1. `model-quirks.ts`：删 `openaiEffort`；`trimEffort` 收窄为 deepseek
   专用（注释注明 cherry 特例出处）
2. gpt/glm/kimi 的 `reasoningEffort` 改透传（grok/claude 已透传不动）
3. 删三家死 effortMap（gpt/glm/kimi；grok 表项本无此字段，评审修正
   原稿笔误），deepseek 保留（anthropic 线真消费）
4. 删 `effortValues` 字段（零消费；将来 UI 选档按 cherry `controls`
   模式重建）
5. 各表项注释同步官方出处与透传/特例决策
6. `anthropic-adapter.ts` 不动（effortMap 查表保留）；测试同步更新

行为变化：gpt 增强（xhigh/max 原生档直达，原被压 high）；glm 不变
（官方自折 xhigh→max，与现映射等价）；deepseek/claude/grok 不变；
kimi 的 xhigh wire 从 max 变 xhigh——注意 xhigh 是系统默认档
（store.ts:69 / providers.ts:331 缺省值），实测若 400 即默认路径故障，
最高优先回退此项。

### 真 Key 实测收敛项

- kimi：medium/xhigh 透传是否 400、官方折叠方向（xhigh 为默认档，最高优先）
- grok：max 透传行为（官方未声明）
- ~~gpt：旧模型对 xhigh/max 的接受度~~ → 已决策不考虑旧模型（2026-08-14）

## 五、后续行动

- [ ] 发送前 sanitize 层：已定性为前瞻储备（cherryin 特例非通用防线），
      与多轮工具循环一并引入
- [x] 核对 effort 值域裁剪语义 → 已定稿（第四节）并已实施（2026-08-14，全量测试 1439 通过）
- [ ] feature 化扩展点：仅记录，暂不实施
- [ ] 多轮工具循环步数硬上限（stepCountIs(N) 模式）：若未来对话助手
      引入多轮工具循环（RAG + 写作工具连用）时实施，防失控
