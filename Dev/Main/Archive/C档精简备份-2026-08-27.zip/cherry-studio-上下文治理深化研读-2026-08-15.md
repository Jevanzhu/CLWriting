# cherry-studio 上下文治理深化研读

- 日期：2026-08-15
- 研读对象：`Dev/参考项目/cherry-studio` 的上下文治理模块（纯代码深挖，落到"可直接抄的数据结构/算法/函数签名"级别）
- 范围：
- 归档：2026-08-24 移入 Archive/（原 04-调研/；所支撑的 8-15 借鉴计划已收口归档）。
  - `packages/aiCore/src/core/context/`（middleware / janitor / durableCompaction / offloader / truncator / adapter / modelMessageAdapter / compaction / ensureValidHistory / prompts / tokenUtils / types）
  - `src/main/ai/messages/maxMessagesWindow.ts`
  - 相关调用方：`src/main/ai/runtime/aiSdk/params/features/inLoopCompaction.ts`、`src/main/ai/streamManager/context/PersistentChatContextProvider.ts`、`src/main/ai/streamManager/context/compaction.ts`、`src/main/ai/constants.ts`、`src/shared/data/types/contextSettings.ts`、`src/main/ai/contextBuild/toolOutputStore.ts`、`src/main/ai/tools/adapters/aiSdk/builtin/FsReadTool.ts`
  - 对应测试：`packages/aiCore/src/core/context/__tests__/*.test.ts`、`src/main/ai/messages/__tests__/maxMessagesWindow.test.ts`、`src/main/ai/runtime/aiSdk/params/features/__tests__/inLoopCompaction.test.ts`
- 关联旧报告：~~`archive/参考项目双研读与借鉴落地计划-2026-08-14.md`~~（原档已删；CS-6 ~ CS-12 已并入 8-15 唯一计划文档 第九节）

> 所有行号以参考项目根目录为基准（如 `packages/aiCore/src/core/context/middleware.ts:146-270`）。引用方式：`路径:行号`。

---

## 一、总体认知

本专题在 cherry-studio 里不是"一个模块"，而是**两个海拔 + 一条中间层**的职责切分：

1. **IR（Intermediate Representation）海拔**（`packages/aiCore/src/core/context/`）——纯数据、零 UI、零存储依赖的上下文治理核心，由 `@context-chef` 系列库 vendored 而来（MIT 同作者，见各文件头部注释），裁剪到 cherry 实际用的面。内部统一用 `ContextMessage`（types.ts:59-83）做中间表示，role 只有 system/user/assistant/tool 四种，tool_calls 结构固定，内容一律字符串（media 走 `attachments` 字段只存"存在性信号"）。
2. **AI SDK 海拔（middleware / adapter / modelMessageAdapter / compaction）**——把 IR 接到 `@ai-sdk/provider` 的 `LanguageModelV3Prompt` 和 `ai` 的 `ModelMessage` 两套外部类型上，做"无损往返"（`_originalText` / `_userContent` 等 pass-through 字段实现字节级还原）。
3. **应用海拔（src/main/ai）**——真正持有存储与预算语义：`maxMessagesWindow`（纯滑动窗口）、`inLoopCompaction`（prepareStep 钩子）、`PersistentChatContextProvider`（turn-start 持久化压缩）、`constants.ts`（所有预算比例的唯一事实源）、`toolOutputStore.ts`（VFS 持久化落盘）、`FsReadTool`（读取回传协议）。

核心管线就是旧报告 CS-7 说的五步：**截断大 tool 结果 → 机械压缩（pruneMessages）→ 转 IR 并分离 system → token 预算压缩（Janitor/onBeforeCompress）→ 重组回 AI SDK**（middleware.ts:195-225）。但代码深挖后能看到的远比旧报告多：这五步背后有一套完整的**回合（turn）语义**、**预算钳制**、**内容寻址**、**无损往返**和**no-op 引用透传**的纪律，本文逐条展开。

---

## 二、深化条目

### 2.1 IR 消息类型（一切管线的中间结构）

**代码位置**：`packages/aiCore/src/core/context/types.ts:18-83`

**核心数据结构**：

```ts
export type Role = 'system' | 'user' | 'assistant' | 'tool'   // types.ts:18

export interface ToolCall {
  id: string
  type: 'function'
  function: { name: string; arguments: string }  // arguments 是 JSON 字符串
}                                                  // types.ts:20-27

export interface ContextMessage {
  role: Role
  content: string
  name?: string
  tool_calls?: ToolCall[]
  tool_call_id?: string
  thinking?: ThinkingContent      // { thinking, signature? }  Anthropic 回传必需
  redacted_thinking?: RedactedThinking  // { data }  opaque，原样回传
  attachments?: Attachment[]     // media，仅存在性信号
  [key: string]: unknown         // 允许 adapter pass-through 字段
}                                  // types.ts:59-83
```

**设计理由与踩坑**：
- **content 一律字符串**是刻意选择——IR 只关心"要压缩的文本"，图片/音频的二进制 payload 不进入 IR 的 content，只在 `attachments` 里留存在性信号（`data` 仅在已是字符串时记录，非字符串绝不伪造编码，adapter.ts:75-81）。压缩摘要调用时用 `[image]` / `[document: name]` 占位（janitor.ts:77-81）。
- `[key: string]: unknown` 的 index signature 是"无损往返"的基石：adapter 把 AI SDK 原始 content 存进 `_userContent` / `_assistantContent` / `_toolContent`，把原始文本存进 `_originalText`（adapter.ts:26-33）。下游压缩只改 `content`，`toAISDK` 检测到 `_originalText !== content` 才重建，否则**原样吐回原始 content**（adapter.ts:203）。
- `thinking` 与 `redacted_thinking` 的 `signature`/`data` 字段是 Anthropic 多轮硬要求，注释明确"must be echoed verbatim"（types.ts:32-44）——CLWriting 走 DeepSeek/Kimi 的 `reasoning` 块，同属此类"原样回传"约束。

**对 CLWriting 借鉴**：
- 对话历史中间表示完全可以照搬这套"字符串 content + tool_calls 扁平结构 + 透传 index signature"。CLWriting 的 `ChatMsg`/ContentBlock 目前是 provider 直出（src/ai/provider/types.ts），建议加一层 IR 再转 provider 格式，为后续压缩/摘要铺路。
- 采纳 `_originalText` 变更检测：只改 content 时保留原始块结构（reasoning/tool_use 原样回传），避免多轮带 tools 时丢块。

**成本与优先级**：低 / 高（这是后续所有条目的地基）

---

### 2.2 五步管线 createContextMiddleware（输入输出类型与顺序）

**代码位置**：`packages/aiCore/src/core/context/middleware.ts:146-270`

**核心算法摘录**（transformParams 内的五步）：

```ts
transformParams: async ({ params }) => {
  let { prompt } = params
  // 1. 截断大 tool 结果（可选，truncate 配置）
  if (options.truncate) prompt = await truncateToolResults(prompt, options.truncate, logger)
  // 2. 机械压缩（零 LLM 成本，pruneMessages）
  if (options.compact) prompt = compactPrompt(prompt, options.compact)
  // 3. 转 IR + system 与对话分离——system 是常驻指令，永不压缩
  const allIR = fromAISDK(prompt)
  const systemMessages = allIR.filter((m) => m.role === 'system')
  let conversation = allIR.filter((m) => m.role !== 'system')
  // 4. 预算压缩（仅当配置了 onBeforeCompress）
  if (janitor) conversation = await janitor.compress(conversation)
  // 5. 重组：system 在前，conversation 在后，转回 AI SDK
  prompt = toAISDK([...systemMessages, ...conversation])
  return { ...params, prompt }
}                                    // middleware.ts:195-225
```

**设计理由与踩坑**：
- **顺序即纪律**：先机械（免费）后智能（花钱）；system 永远在压缩之外（middleware.ts:209-210 注释）。
- **预算开关是显式的**：只有配了 `onBeforeCompress` 才构造 Janitor（`const budgeting = Boolean(options.onBeforeCompress)`，middleware.ts:153），配了 onBeforeCompress 但没有 `contextWindow` 会直接 throw（middleware.ts:155-160）。truncate/compact-only 配置完全无 Janitor、无 token 捕获。
- **wrapGenerate / wrapStream 捕获真实 usage**：`result.usage?.inputTokens?.total` 喂给 janitor.feedTokenUsage；缺失时**只警告一次**（`usageWarned` 标志，middleware.ts:232-240）。注意只认 `inputTokens.total`——如果 provider 只报 output 或不报 total，压缩触发可能不准，这有专门警告文案。
- **压缩未持久化告警**：连续 `COMPRESS_WITHOUT_PERSISTENCE_WARN_THRESHOLD = 3` 次压缩触发才 warn 一次（middleware.ts:32-33, 168-180）——in-flight 压缩只改写本次请求，不改存储，历史每次调用重新膨胀，payload 无界增长。这是"in-flight 与 durable 两条腿"的明确分工信号。

**对 CLWriting 借鉴**：
- 当前 CLWriting 没有"中间层"概念——generate 直接吃 provider 格式。可在 `runTask` 的 `run` 回调（src/ai/orchestrate/chat.ts:277-295）外包一层中间件：先机械 sanitize + 截断，再按 token 预算压缩。
- 采纳"system 永不压缩 + 压缩前先机械"的顺序；CLWriting 的 system prompt 是稳定的（设定+职责），正好符合"前缀稳定利于 KV cache"的既有设计（chat.ts:267-269）。

**成本与优先级**：中 / 高

---

### 2.3 pruneMessages 的可配置保留策略（compact 配置细节）

**代码位置**：`packages/aiCore/src/core/context/middleware.ts:79-105`（CompactConfig 类型）与 `:281-302`（compactPrompt 实现）

**核心数据结构**（这是 AI SDK 自带 `pruneMessages` 的配置形状，cherry 只是透传）：

```ts
export interface CompactConfig {
  reasoning?: 'all' | 'before-last-message' | 'none'          // 默认 'none'（全保留）
  toolCalls?:
    | 'all'
    | 'before-last-message'
    | `before-last-${number}-messages`
    | 'none'
    | Array<{ type: ...; tools?: string[] }>                    // 可精确到 tool 名
  emptyMessages?: 'keep' | 'remove'                             // 默认 'remove'
}                                    // middleware.ts:79-105
```

**设计理由与踩坑**：
- `reasoning` 的 `before-last-message` 语义：只保留最后一条 assistant 消息的推理内容，其余全删——"最后一条要展示思维过程，历史里的思考不占预算"。
- `toolCalls` 支持数组形式**按工具名精确剪**（`tools?: string[]`），可"只剪某个 tool 的调用"。字符串形式 `before-last-N-messages` 用模板字面量类型，从 TS 层面约束格式。
- `compactPrompt` 的 **cast 安全性注释**很关键（middleware.ts:272-280）：`LanguageModelV3Message` 与 `ModelMessage` 运行时结构相同但 TS 类型不同（ImagePart、FilePart.data 差异），因为 pruneMessages 只过滤不转换，输出 content 的每个 part 都是原始 V3 part，所以 cast 安全。**这是"仅过滤不改形"才成立的捷径**。
- pruneMessages 后空消息默认 `remove`——防止空 content 消息进请求（这正是 CLWriting `sanitizeHistory` 在治的 #3a/#3b）。

**对 CLWriting 借鉴**：
- 若引入 pruning，可直接抄这三档：reasoning/toolCalls/emptyMessages。CLWriting 的场景主要是 tool_use/tool_result 配对（chat.ts 已按回合保留），可先上 `emptyMessages: 'remove'` 和 `toolCalls: 'before-last-1-messages'`。
- 不需要自己实现 prune——AI SDK 的 `pruneMessages` 是现成的，CLWriting 若用 openai 协议可用 `ai` 包；否则手写同语义的"按块过滤 + 空消息剔除"。

**成本与优先级**：低 / 高

---

### 2.4 groupIntoTurns 回合切割的精确判定规则

**代码位置**：`packages/aiCore/src/core/context/janitor.ts:40-63`（实现）、Turn 类型定义在 janitor.ts:23-26

**核心算法摘录**：

```ts
export interface Turn { startIndex: number; endIndex: number }   // endIndex 排他

export function groupIntoTurns(history: ContextMessage[]): Turn[] {
  const turns: Turn[] = []
  let i = 0
  while (i < history.length) {
    const msg = history[i]
    if (msg.role === 'assistant' && msg.tool_calls?.length) {
      // 原子回合：assistant + 其后续全部 tool 结果
      const start = i
      i++
      while (i < history.length && history[i].role === 'tool') { i++ }
      turns.push({ startIndex: start, endIndex: i })
    } else {
      // 单消息回合：user、system 或纯文本 assistant
      turns.push({ startIndex: i, endIndex: i + 1 })
      i++
    }
  }
  return turns
}                                        // janitor.ts:40-63
```

**精确判定规则**（注释 + 实现归纳）：
1. `user` → 单消息回合；
2. `system` → 单消息回合（但 durable 层会先抽走 system，见 2.5）；
3. `assistant`（无 tool_calls）→ 单消息回合；
4. `assistant`（**有 tool_calls**）+ **其后续所有连续 `role:'tool'` 消息** → 一个原子回合。

**设计理由与踩坑**：
- 关键在"切割永不落在 tool 配对中间"。assistant 发 tool_calls 后连续若干条 tool 结果同属一个回合，因此 `splitIndex` 永远指向回合边界（`turns[splitTurn].startIndex`），后续无需 post-hoc 修正（janitor.ts:36-39 注释"eliminates the need for post-hoc split-index corrections"）。
- 一次 assistant 可以发多个 tool_calls，其 tool 结果多条连续排在一起——`while (i < history.length && history[i].role === 'tool')` 一次吃光，保证 N 个调用 N 个结果全在一个回合。
- 注意：它**只认 role==='tool' 的连续段**，若中间插了 user 消息则视为新回合（回合中断）。这与 ensureValidHistory 先消毒保证"tool 消息必然紧跟其 assistant"的前提呼应。

**对 CLWriting 借鉴**：
- CLWriting 已有 `trimHistory`（src/ai/prompts/chat.ts:82-100），但它是"从尾部往前数纯文本 user 消息"的粗估，不处理 tool 配对原子性——`groupIntoTurns` 的精确版可直接替换（或用它重写 trimHistory 的边界判定）。
- 这个函数是 planCompaction / Janitor / 摘要适配器共用的地基，**值得作为独立纯函数先落地 + 配套测试**（test 写法见 2.19）。

**成本与优先级**：低 / 高

---

### 2.5 planCompaction 与 compactHistory：no-op 引用透传

**代码位置**：`packages/aiCore/src/core/context/durableCompaction.ts:48-67`（planCompaction）、`:85-107`（compactHistory）

**核心数据结构**：

```ts
export interface CompactionPlan {
  system: ContextMessage[]       // system 原样保留，永不摘要
  toSummarize: ContextMessage[]  // 要摘要的旧对话段（已排除 system）
  toKeep: ContextMessage[]       // 保留原样的最近回合
}                                 // durableCompaction.ts:24-34

export async function compactHistory(
  history: ContextMessage[],
  compress: (messages: ContextMessage[]) => Promise<string>,
  options: PlanCompactionOptions & SummarizeHistoryOptions
): Promise<ContextMessage[]> {
  const { keepRecentTurns, ...summarizeOptions } = options
  const plan = planCompaction(history, { keepRecentTurns })
  // 1) 无物可压缩 → 返回原数组引用
  if (plan.toSummarize.length === 0) return history
  const summary = await summarizeHistory(plan.toSummarize, compress, summarizeOptions)
  // 2) 摘要为空 → 同样返回原引用，绝不用空标记覆盖旧回合
  if (!summary.trim()) return history
  const summaryMessage: ContextMessage = {
    role: 'user',
    content: ContextPrompts.getCompactSummaryWrapper(summary)
  }
  return [...plan.system, summaryMessage, ...plan.toKeep]
}                                  // durableCompaction.ts:85-107
```

**设计理由与踩坑**：
- **no-op 判定是引用相等而非深比较**：返回 `history` 原引用，调用方 `result === history` 一行判断"要不要持久化/要不要 override"。零开销、无歧义。`compactModelMessages` 在 ModelMessage 海拔同样透传（compaction.ts:53），inLoopCompaction 用 `compacted === candidate` 判定 no-op 并 settle 为 `skipped`（inLoopCompaction.ts:270-278）——**这是把一个 no-op 误报成"已压缩"的著名坑的修复**（#17837）。
- planCompaction 的 `keepRecentTurns` 边界处理（durableCompaction.ts:49-60）：`keep = Math.max(0, Math.floor(keepRecentTurns))`；`splitTurn = Math.max(0, turns.length - keep)`；`splitIndex = splitTurn < turns.length ? turns[splitTurn].startIndex : conversation.length`。keep=0 时 splitTurn===turns.length → summarize 全部；keep >= 回合数 → toSummarize 空。
- **切割前先 ensureValidHistory**（durableCompaction.ts:53）：保证无孤儿 tool 结果再分组，否则分组会被脏数据打乱。
- 摘要以 **user** 消息插入（Claude Code 风格），可能导致"两个连续 user 消息"——注释明确这是合法 ModelMessage（Anthropic 会合并同 role，OpenAI 接受），但**若喂给要求严格交替的消费者要自己处理**（compaction.ts:35-40）。

**对 CLWriting 借鉴**：
- **引用透传判 no-op 是本次最有复用价值的小技巧**：CLWriting 的持久化点（如自愈闭环的摘要写库、对话历史裁剪）都可采纳"no-op 返回原引用，调用方 `===` 跳过写"。
- 摘要用 user 消息 + "续写框架"（getCompactSummaryWrapper，见 2.10）可直接照抄，作为长对话/长章节的持久化摘要格式。

**成本与优先级**：低 / 高

---

### 2.6 Offloader：内容寻址 + 摘录标记 + 防二次截断

**代码位置**：`packages/aiCore/src/core/context/offloader.ts:108-185`（Offloader）、`:97-106`（computeHeadTailExcerpt）、`:72-82`（snapToLineBoundary）

**核心算法摘录**：

```ts
private async _generateFilename(content: string) {
  // 内容寻址：相同内容 → 同一文件 → 重复 offload 幂等
  const digest = await globalThis.crypto.subtle.digest('SHA-256', new TextEncoder().encode(content))
  const hash = Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, '0')).join('').substring(0, 16)
  const filename = `vfs_${hash}.txt`
  const uri = `context://vfs/${filename}`
  return { filename, uri }
}                                       // offloader.ts:117-130

export function computeHeadTailExcerpt(content, headChars, tailChars): HeadTailExcerpt {
  const headEnd = headChars > 0 ? snapToLineBoundary(content, headChars, 'head') : 0
  const tailStart = tailChars > 0 ? snapToLineBoundary(content, content.length - tailChars, 'tail') : content.length
  return {
    head: headEnd > 0 ? content.slice(0, headEnd) : '',
    tail: tailStart < content.length ? content.slice(tailStart) : '',
    totalChars: content.length,
    totalLines: content.split('\n').length
  }
}                                        // offloader.ts:97-106

public async offloadAsync(content, options?): Promise<VFSResult> {
  // 1) 不超阈值 → 原样返回
  if (content.length <= activeThreshold) return { isOffloaded: false, content }
  // 2) head+tail 已覆盖全文 → 无需 offload
  if (headChars + tailChars >= content.length) return { isOffloaded: false, content }
  // 3) 写库（exists() 短路跳过重复写）
  if (!(this.adapter.exists && await this.adapter.exists(filename))) {
    await this.adapter.write(filename, content)
  }
  // 4) 构建截断标记（含 URI + 物理路径 + head/tail 摘录）
  const truncated = this._buildTruncatedMarker(content, uri, headChars, tailChars, physicalPath)
  return { isOffloaded: true, content: truncated, uri }
}                                        // offloader.ts:153-184
```

**设计理由与踩坑**：
- **SHA-256 前 16 hex 作文件名**：64 bit 碰撞概率足够低；且**跨实现字节一致**——主进程 `computeVfsFilename`（toolOutputStore.ts:30-33）用 node:crypto 算同款 `vfs_<sha256[:16]>.txt`，保证 persist-time 与 in-flight 两条 lane 收敛到同一 blob、同一标记字节（provider 前缀缓存存活的前提）。测试用 node:crypto 对拍（offloader.test.ts:253-263）。
- **行边界对齐**（snapToLineBoundary）：head 向后回退到最近的 `\n`+1，tail 向前进到最近的 `\n`+1——保证摘录只含完整行，模型可读。
- **防二次截断**：truncator 在 text 超阈值时检查 `text.includes(PERSISTED_OUTPUT_TAG)`（truncator.ts:151-154），命中则原样放行——否则"标记本身比阈值大"时会把标记再次 offload，形成**标记指向标记**的递归。仅在超阈值时检查，避免扫描每个输出。
- **写先于取物理路径**：DB 类 adapter 写时才创建记录、才知道路径（offloader.ts:168-174 注释）；`exists()` 只短路写，不短路路径解析。
- **adapter 接口**：write/read 必填，exists/list/delete/getPhysicalPath 可选。无 getPhysicalPath 时标记只带 URI（无文件系统语义，如 DB/内存适配器）；有则**以物理路径为主句柄**（模型可用现成 fs_read 工具读回），URI 降为替代（prompts.ts:72-74）。

**对 CLWriting 借鉴**：
- CLWriting 的"长章节正文/设定 dump/审查报告进上下文"场景：可把正文前 N 千字之外的全文 offload 到书库（git 仓库内 blob 目录），上下文里只放"头部摘录 + 定位符"，需要时用已有工具读回。
- **先落地最便宜的版本**：只要 `computeHeadTailExcerpt + 内容寻址文件名 + 简单文件适配器`，不接 UI。

**成本与优先级**：中 / 中

---

### 2.7 truncator 的 perTool 策略与 entity codec（结构感知裁剪）

**代码位置**：`packages/aiCore/src/core/context/truncator.ts:86-201`（主函数）、`:221-276`（truncateEntities）、`:283-299`（buildPolicyMap）、`:30-33`（EntityToolOutputCodec）

**核心数据结构**：

```ts
export interface EntityToolOutputCodec {
  deflate(value: unknown): { skeleton: unknown; blobs: Array<{ key: string; text: string }> } | null
  assemble(skeleton: unknown, texts: Record<string, string>): unknown
}                                            // truncator.ts:30-33
```

**perTool 策略**（truncator.ts:35-80）：
- 字符串条目 = preserve（该 tool 结果永不截断，storage 完全绕过）；
- 对象条目 = 覆盖 threshold/headChars/tailChars + 可选 codec（结构化裁剪）；
- **同名多次出现取最后一条**（buildPolicyMap 循环覆盖，Map.set，truncator.ts:283-299）；
- 通配符/glob **不支持**；storage 不能 per-tool 覆盖。

**设计理由与踩坑**：
- **entity codec 是"函数即数据"的注入**：aiCore 不 import 任何具体 tool 代码，codec 由主进程作为数据传入。deflate 把结构化 JSON 拆成"身份骨架 + 每实体文本 blob"，assemble 按 key 回填（可能被裁剪的）文本——identity 骨架原样保留，只有超长实体文本被替换。`blob.key` 是 JSON-pointer-lite（`"/<index>/content"`），**固定格式因为持久化信封复用**：存储的数据要能在无 codec 时正确 inflate。
- **assemble 必须保持键插入顺序**——重组后的值被字符串化进 prompt，跨 lane 字节稳定才能命中 provider 前缀缓存（truncator.ts:26-29 注释）。
- **per-blob 存储失败保留全文**：`A per-blob storage failure keeps that blob's full text — never trade data for a broken marker`（truncator.ts:219, 252-258）。storage 整体失败则 fall through 到简单截断（truncator.ts:172-178），日志告警。
- 无 storage 的简单截断：head + `\n--- truncated (N lines, M chars total) ---\n` + tail（truncator.ts:186-189）。

**对 CLWriting 借鉴**：
- CLWriting 审查/机检工具的结果若带大 JSON（规则命中列表等），可用 codec 把"命中条目列表"拆骨架+正文，只裁超长文本。
- perTool 的 preserve（字符串条目）思想适合"某些工具输出必须完整"（如写章结果摘要）。

**成本与优先级**：中 / 中

---

### 2.8 压缩请求自身的预算钳制：STUB_ESCALATION 与 clampToInputBudget

**代码位置**：`packages/aiCore/src/core/context/janitor.ts:226-266`（summarizeHistory）、`:172`（STUB_ESCALATION）、`:182-204`（clampToInputBudget）

**核心算法摘录**：

```ts
const STUB_ESCALATION = [4000, 1000, 200, 0]   // 0 = 全部 stub（janitor.ts:172）

// 渐进 stub 大 tool 结果，直到压缩请求输入塞进窗口
if (opts.maxInputTokens !== undefined) {
  for (const threshold of STUB_ESCALATION) {
    if (estimateObject(compressionMessages) <= opts.maxInputTokens) break
    if (opts.toolResultStubThreshold !== undefined && threshold >= opts.toolResultStubThreshold) continue
    compressionMessages = assemble(threshold)
  }
  // stub 全部仍超 → 最后手段 clamp
  if (estimateObject(compressionMessages) > opts.maxInputTokens) {
    compressionMessages = clampToInputBudget(compressionMessages, opts.maxInputTokens)
  }
}                                          // janitor.ts:253-262

function clampToInputBudget(messages, maxInputTokens): ContextMessage[] {
  if (messages.length <= 2) return messages
  const first = messages[0]          // 可能是先前累积摘要，必须留
  const instruction = messages[messages.length - 1]  // 尾部指令必须留
  const middle = messages.slice(1, -1)
  let used = estimateObject([first, instruction])
  const kept: ContextMessage[] = []
  // 从尾部向前贪心，能装多少装多少
  for (let i = middle.length - 1; i >= 0; i--) {
    const cost = estimateObject(middle[i])
    if (used + cost > maxInputTokens) break
    kept.unshift(middle[i]); used += cost
  }
  const omitted = middle.length - kept.length
  if (omitted === 0) return messages
  const marker: ContextMessage = {
    role: 'user',
    content: `[${omitted} earlier message(s) omitted — they did not fit the summarizer's context budget. Say so in the summary rather than implying full coverage.]`
  }
  return [first, marker, ...kept, instruction]
}                                          // janitor.ts:182-204
```

**设计理由与踩坑**：
- **压缩调用本身是窗口受限请求**：压缩存在的意义是让对话塞进窗口，但摘要调用自己也是窗口受限——agentic 历史带整段 tool 输出，不钳制会超压缩模型窗口，要么硬失败要么把输出预算饿死到空摘要（运行时发现 3/5 次压缩返回空）。这就是旧报告 CS-10 的主旨，代码细节在此。
- **保留顺序**（clampToInputBudget）：**首条**（对先带摘要的调用方，首条=全部累积历史，绝不可丢）+ **尾部指令** + **从尾向前尽量多的最近消息**，中间丢的部分用 in-band user 标记声明"摘要不得声称覆盖全量"——**绝不静默丢**。
- **渐进 stub 顺序**：4000 → 1000 → 200 → 0（全 stub）。每次先 `estimateObject(compressionMessages)` 估 token，超了就换更狠的 stub 阈值。注意 `opts.toolResultStubThreshold !== undefined && threshold >= opts.toolResultStubThreshold` 的保护——用户显式给了 stub 阈值时，不降级到比它还狠的档。
- **token 估算用 estimateObject**（tokenUtils.ts:31-36）：CJK ~1.5 tokens/char，其他 ~0.3 tokens/char（~3.3 chars/token），零依赖快速估算——这是**压缩触发/钳制的"测量口径"**，与真实 tokenizer 不必一致，只要单调可比。

**对 CLWriting 借鉴**：
- CLWriting 没有 tool 大输出塞进摘要的坑，但**有"长章节正文塞进审查/润色请求"的坑**——同一钳制逻辑可直接搬：渐进裁剪 + 保头保尾 + 声明遗漏。
- **STUB_ESCALATION 的"渐进降档"思想**比"一次到位"好：先试最便宜的方案，不行再降。CLWriting 的长文注入也可按"完整 → 摘要 → 极简要点"渐进。

**成本与优先级**：低 / 高

---

### 2.9 角色扁平化摘要适配器（tool 角色 → user/assistant 文本）

**代码位置**：`packages/aiCore/src/core/context/middleware.ts:308-361`

**核心算法摘录**：

```ts
function toCompressRole(role: string): CompressRole {
  if (role === 'system' || role === 'user' || role === 'assistant') return role
  return 'user'      // 未知 role 一律降为 user
}                                     // middleware.ts:308-311

export function createCompressionAdapter(
  model: LanguageModel,
  maxOutputTokens: number = COMPRESSION_MIN_OUTPUT_TOKENS
): (messages: ContextMessage[]) => Promise<string> {
  return async (messages) => {
    const formatted = messages.map((m) => {
      if (m.role === 'tool') {
        return { role: 'user', content: `[Tool result${m.tool_call_id ? ` (${m.tool_call_id})` : ''}: ${m.content}]` }
      }
      if (m.role === 'assistant' && m.tool_calls?.length) {
        const toolCallsDesc = m.tool_calls
          .map((tc) => `[Called tool: ${tc.function.name}(${tc.function.arguments})]`).join('\n')
        return { role: 'assistant', content: m.content ? `${m.content}\n${toolCallsDesc}` : toolCallsDesc }
      }
      return { role: toCompressRole(m.role), content: m.content }
    })
    const { text } = await generateText({ model, messages: formatted, maxOutputTokens })
    return text   // 原样返回，空字符串也返回——空摘要由上层 fail-open
  }
}                                      // middleware.ts:320-361
```

**设计理由与踩坑**：
- **摘要模型只接受 system/user/assistant**，tool 消息必须扁平化。tool → `user` 且内容包成 `[Tool result (id): content]`；assistant 带 tool_calls → 追加 `[Called tool: name(args)]`。
- **输出格式模板**（这就是旧报告 CS-11 说的"输出格式模板"）：
  - tool 消息 → `[Tool result (call_1): <content>]`
  - assistant tool_calls → `[Called tool: foo({"a":1})]`（多行 `\n` 连接）
  - 其余 → 原 role + content。
- **空摘要必须原样返回**（middleware.ts:353-359 的坑注释）：**绝不替换占位符**。因为上层（compactHistory、PersistentChatContextProvider）都靠"空摘要 fail-open 保留历史"，一旦在这里填占位符，那些 guard 永不触发，折叠回合会被占位符替换掉——历史被静默丢弃（#17837 同族）。
- 摘要模型输出 budget 由 maxOutputTokens 控制，默认 COMPRESSION_MIN_OUTPUT_TOKENS(4096)。

**对 CLWriting 借鉴**：
- CLWriting 做摘要/压缩时若历史含 tool 记录（对话助手），这段纯函数直接抄。
- 空摘要 fail-open 的纪律必须一起抄：**摘要空 ≠ 压缩成功，上层要保留原历史**。

**成本与优先级**：低 / 高

---

### 2.10 摘要 prompt 指令模板与续写框架（formatCompactSummary / getCompactSummaryWrapper）

**代码位置**：`packages/aiCore/src/core/context/prompts.ts:97-153`（CONTEXT_COMPACTION_INSTRUCTION）、`:167-181`（formatCompactSummary）、`:188-193`（getCompactSummaryWrapper）、`:199-206`（getFallbackCompressionSummary）、`:17`（PERSISTED_OUTPUT_TAG）

**核心片段**：

```ts
// 摘要指令结构：<analysis> 思考草稿 + <summary> 正式摘要（两段式，scratchpad 模式可测地提升质量）
CONTEXT_COMPACTION_INSTRUCTION: `
You have been working on the task described above but have not yet completed it. Write a continuation summary...
Before providing your final summary, wrap your analysis in <analysis></analysis> tags...
Your final summary (inside <summary></summary> tags) should be structured, concise, and actionable. Include:
1. Task Overview  2. Current State  3. Important Discoveries  4. Next Steps  5. Context to Preserve
...example format included...
`.trim()

// 提取：剥 <analysis>，取 <summary> 内容，塌缩多余空行
formatCompactSummary: (raw) => {
  let out = raw.replace(/<analysis>[\s\S]*?<\/analysis>/gi, '')
  const match = out.match(/<summary>([\s\S]*?)<\/summary>/i)
  if (match) out = match[1]
  return out.replace(/\n{3,}/g, '\n\n').trim()
}

// 续写框架（持久化进 compaction_summary 行的前缀/后缀）
getCompactSummaryWrapper: (summary) => `
This session is being continued from a previous conversation that ran out of context...
Continue the conversation from where it left off without asking the user any further questions.
Resume directly — do not acknowledge the summary, do not recap...
`.trim()
```

**设计理由与踩坑**：
- **两段式摘要指令**（analysis + summary）比单段摘要质量可测地高；analysis 是草稿会被 strip，summary 才是正式产出。
- **formatCompactSummary 的正则**：`/gi` 剥全部 analysis 块；`<summary>` 提取（**没找到 summary 标签则 fallback 到剥完 analysis 的全文**）；`\n{3,} → \n\n` 塌缩空行。
- **续写框架是持久化契约**：明确告诉模型"这是续写不是新对话、不要复述、不要客套、直接接上"——写入 DB 的 `compaction_summary` 行的就是这个包装（durableCompaction 用它包摘要，PersistentChatContextProvider 的 summaryRow 也用它，见 streamManager compaction.ts:51-68）。
- **PERSISTED_OUTPUT_TAG = '<persisted-output>'** 是截断标记的锚，truncator 靠它防二次截断。

**对 CLWriting 借鉴**：
- 中文版"续写框架"直接可写：摘要 + "请基于以上摘要无缝继续，不要复述不要客套"。这对 CLWriting 的"长对话/长章节续写"极有用。
- 两段式指令 + 结构化摘要（任务/状态/发现/下一步/保留上下文）是通用模式，审查报告、自愈闭环的失败记录都能用同款骨架。

**成本与优先级**：低 / 高

---

### 2.11 摘要输入预处理：attachment 占位 + 大 tool 结果 stub（含 tool 名映射）

**代码位置**：`packages/aiCore/src/core/context/janitor.ts:77-150`

**核心算法摘录**：

```ts
// attachment → 单行占位（文件名可引用）
//  { mediaType:'image/png', filename:'photo.png' } → '[image: photo.png]'
//  { mediaType:'application/pdf' }                  → '[document]'
function attachmentToPlaceholder(att) {
  const mt = att.mediaType.toLowerCase()
  const kind = mt.startsWith('image/') ? 'image' : mt ? 'document' : 'attachment'
  return att.filename ? `[${kind}: ${att.filename}]` : `[${kind}]`
}                                        // janitor.ts:77-81

// 大 tool 结果 → 一行 stub，保留 tool 名 + 尺寸
//  `[Tool fs_read returned 87123 chars; omitted before summarization]`
function stripLargeToolResultsForCompression(messages, threshold) {
  const nameMap = buildToolNameMap(messages)   // tool_call_id → tool 名
  return messages.map((msg) => {
    if (msg.role !== 'tool') return msg
    if (msg.content.length <= threshold) return msg
    const name = (msg.tool_call_id && nameMap.get(msg.tool_call_id)) ?? 'unknown'
    return { ...msg, content: `[Tool ${name} returned ${msg.content.length} chars; omitted before summarization]` }
  })
}                                        // janitor.ts:141-150
```

**设计理由与踩坑**：
- **压缩模型永远不见二进制 attachment**——只给 `[image]`/`[document: name]` 占位，避免 base64 payload 撑爆压缩调用自身（janitor.ts:85-95 注释）。
- **tool 名映射**：先遍历所有 assistant 的 tool_calls 建 `tool_call_id → function.name` Map（janitor.ts:113-123），再把超阈值 tool 结果换成带名字 + 字符数的 stub——摘要仍能引用"这个操作发生了什么"，tool_use↔tool_result 配对结构保留。
- 纯函数，不 mutate；无 attachment 消息按引用透传（零分配）。
- 注意 stub 阈值是**字符数**（`content.length <= threshold`），不是 token——字符数便宜且单调可比。

**对 CLWriting 借鉴**：
- CLWriting 对话助手摘要场景没有大 tool 输出（chat 工具返回的都是短 summary），但写稿链路若有"设定 dump/大纲"塞摘要，同款 stub + 名字保留思路适用。

**成本与优先级**：低 / 中

---

### 2.12 Janitor：in-flight 预算压缩（feedTokenUsage + E10 抑制 + onBeforeCompress 再评估）

**代码位置**：`packages/aiCore/src/core/context/janitor.ts:332-429`

**核心算法摘录**：

```ts
export class Janitor {
  private _externalTokenUsage: number | null = null   // 外部真实 usage（一次消费）
  private _suppressNextCompression = false             // E10：压缩后抑制下一次检查

  feedTokenUsage(tokenCount) { this._externalTokenUsage = tokenCount }

  async compress(history) {
    const evaluation = this.evaluateBudget(history)      // 超预算？算 splitIndex
    if (evaluation === null) return history
    let { splitIndex } = evaluation
    const hook = this.config.onBeforeCompress
    if (hook) {
      const modified = await hook(history, { currentTokens, limit: this.config.contextWindow })
      if (modified != null) {
        const reEval = this.evaluateBudget(modified)      // 对 hook 结果再评估
        if (reEval === null) return modified
        history = modified; splitIndex = reEval.splitIndex
      }
    }
    return this.executeCompression(history, splitIndex)   // 机械 drop + onCompress
  }

  private evaluateBudget(history) {
    if (history.length === 0) return null
    if (this._suppressNextCompression) { this._suppressNextCompression = false; return null }
    const currentTokens = this._externalTokenUsage ?? estimateObject(history)
    this._externalTokenUsage = null
    if (currentTokens <= this.config.contextWindow) return null
    const turns = groupIntoTurns(history)
    const keepCount = Math.min(this.config.preserveRecentMessages ?? 1, turns.length)
    const splitTurn = turns.length - keepCount
    if (splitTurn <= 0) return null
    return { splitIndex: turns[splitTurn].startIndex, currentTokens }
  }
}                                        // janitor.ts:345-413
```

**设计理由与踩坑**：
- **预算来源双轨**：`feedTokenUsage`（真实 usage，一次消费）优先，否则 `estimateObject`（字符启发式）兜底（janitor.ts:397-399）。
- **E10 抑制**：`_suppressNextCompression` 在压缩后置 true，下次 evaluateBudget 直接跳过——**避免级联反复压缩**（每两次请求才压缩一次，历史重新膨胀的窗口被拉长，配合 COMPRESS_WITHOUT_PERSISTENCE_WARN_THRESHOLD 提示持久化）。
- **onBeforeCompress 钩子契约**：返回修改后历史则**再评估**（可能已降预算直接返回 modified），返回 null/undefined 则机械 drop；钩子抛错会穿透 transformParams（注释明示"no fallback path"）。
- **机械 drop 默认保留 1 回合**（`DEFAULT_PRESERVE_RECENT_MESSAGES = 1`，janitor.ts:19, 406），onCompress 收到的是 **system 占位摘要**（getFallbackCompressionSummary）而不是 LLM 摘要——in-flight 路径不调 LLM。

**对 CLWriting 借鉴**：
- CLWriting 是自研链路，可把"预算检查 + hook 再评估 + 机械兜底 drop"这一事件顺序搬进 generate 前。**hook 可被再评估**这一点尤其重要：调用方（如注入已压缩摘要）返回修改历史后，系统自己再量一次，避免"改完还是超"。
- E10 抑制可防止"压缩一次、下次又立即压缩"的死循环。

**成本与优先级**：中 / 中

---

### 2.13 无损往返 adapter（fromAISDK/toAISDK 与 fromModelMessages/toModelMessages）

**代码位置**：`packages/aiCore/src/core/context/adapter.ts:47-301`、`packages/aiCore/src/core/context/modelMessageAdapter.ts:56-301`

**核心设计**：
- **两种海拔两套 pass-through**：V3 prompt 用 `_userContent/_assistantContent/_toolContent/_providerOptions/_toolName/_originalText`（adapter.ts:26-33），ModelMessage 用 `_mmUserContent/_mm*…`（modelMessageAdapter.ts:32-39）——**故意不同前缀**防两套 adapter 互相误读。
- **修改检测**：`contentModified = _originalText !== undefined && _originalText !== content`。未修改 → 原样回吐原始 content（无损）；修改过（压缩清空 tool 结果）或新增消息（摘要）→ 从 IR 字段重建（adapter.ts:203, 218, 229）。
- **tool 消息一对多/多对一**：一个 source tool 消息映射 N 个 IR tool 消息（每 result 一条），toAISDK 再按连续 IR tool 段 coalesce 回一条（adapter.ts:152-173, 236-277）。**providerOptions 只在首条 IR 上挂一次**，避免 coalesce 时重复（Anthropic cache breakpoint 场景）。
- **内联 tool-result 防重复**：provider 自执行工具（web search/code exec）在同一 assistant 消息内联带 tool-result，`inlineAnsweredIds` 集合排除这些 id，避免 ensureValidHistory 注入伪占位符（adapter.ts:103-110）。
- **stringifyToolOutput**：把各种 output 类型（text/json/content/error-*）统一成字符串（adapter.ts:285-301）。
- **边界消毒**：from* 之后过 `ensureValidHistory`（见 2.14），IR 下游假设不变量已满足。

**对 CLWriting 借鉴**：
- CLWriting 若不引 AI SDK 而是自研 provider 层，无损往返这套"原样回吐 + 修改重建"的思路仍值得学：**改动只发生在 content 上，reasoning/tool 结构原样透传**——这正是 DeepSeek/Kimi echoReasoning 需要的。
- `_originalText` 变更检测成本极低，建议直接加进 ChatMsg 扩展字段。

**成本与优先级**：中 / 中

---

### 2.14 ensureValidHistory：边界消毒（孤儿/缺失 tool 结果 + 首条必须 user）

**代码位置**：`packages/aiCore/src/core/context/ensureValidHistory.ts:32-159`

**核心算法摘录**：

```ts
const PLACEHOLDER_TOOL_RESULT = '[No tool result available]'
const PLACEHOLDER_ORPHAN_REMOVED = '[Conversation continues]'

export function ensureValidHistory(history): ContextMessage[] {
  let result = [...history]
  result = fixOrphanToolResults(result)   // 1) 孤儿 tool 结果删除（删空则留占位）
  result = fixMissingToolResults(result)  // 2) assistant 有 tool_calls 缺结果 → 注入合成 tool 结果
  result = ensureFirstMessageIsUser(result) // 3) 首个非 system 必须是 user，否则前置合成 user
  return result
}                                        // ensureValidHistory.ts:32-47
```

**设计理由与踩坑**：
- **fixOrphanToolResults**：删 tool_call_id 无匹配 assistant 的消息；全删空时留 `[Conversation continues]` user 占位（ensureValidHistory.ts:76-80）。
- **fixMissingToolResults**：assistant 有 tool_calls 但后续（到下一个 assistant/user 前）缺对应 tool 结果 → 注入 `[No tool result available]`，并带上 **tool 名（IR name 字段）**，因为 Gemini/strict 中间件会校验 toolName（ensureValidHistory.ts:88-93, 123-130）。
- **ensureFirstMessageIsUser**：首个非 system 不是 user 就前置合成 user 占位。
- 纯函数返回新数组，不 mutate。注释明示"消毒是静默的，要看改了什么就自己 diff"。

**对 CLWriting 借鉴**：
- CLWriting 已有 `sanitizeHistory`（src/ai/prompts/chat.ts:119-），且注释明言"学 cherry-studio ensureValidHistory"（chat.ts:103）。**深挖后发现可补两条**：注入合成 tool 结果时带 tool 名（当前可能丢名）；"首条必须 user"的合成占位文案。
- 消毒后应进 IR 管道（与 2.1 结合），保证压缩/摘要吃到的是干净历史。

**成本与优先级**：低 / 高（大部分已实现，补两条即可）

---

### 2.15 maxMessagesWindow：向前扩展 + normalizeMaxMessages

**代码位置**：`src/main/ai/messages/maxMessagesWindow.ts:36-48`

**核心算法摘录**（全文件仅 48 行）：

```ts
export function normalizeMaxMessages(value: unknown): number | null {
  if (typeof value !== 'number' || !Number.isFinite(value)) return null
  const floored = Math.floor(value)
  return floored >= 1 ? floored : null    // 0/负数/NaN/Infinity/非数 → null（不设限）
}

export function applyMaxMessagesWindow<T extends { role: string }>(messages: T[], maxMessages: number | null): T[] {
  const limit = normalizeMaxMessages(maxMessages)
  if (limit === null || messages.length <= limit) return messages   // 早期返回不是归一化
  let start = messages.length - limit
  while (start > 0 && messages[start].role !== 'user') start--      // 向前扩到 user 行
  return messages.slice(start)
}                                       // maxMessagesWindow.ts:36-48
```

**设计理由与踩坑**：
- **窗口必须落在 user 上**：回复绝不能离开它的提问；continue-dispatch 路径（tool approval 恢复）合法地以 assistant 行结尾，向前修剪会"裁空半个回合"（maxMessagesWindow.ts:5-9 注释）。`while` 向前扩展受当前回合大小约束，非空输入结果永不为空。
- **role-only 切片**：v2 chat 把 tool 调用嵌在 assistant 消息的 parts 里，行级切片不可能 orphan tool 结果（maxMessagesWindow.ts:11-12 注释）——**这就是为什么这里不需要 groupIntoTurns**。
- **早期返回刻意不是归一化**：短于窗口的历史原样返回，绝不把"已 assistant 开头"转成 user 开头——那个保证属于 toModelMessages（做这里会无谓截断大 N 窗口）（maxMessagesWindow.ts:14-18 注释）。
- **normalize 的坑**：PreferenceService 和 assistant 设置 JSON 都直接从 DB 读，无 schema 强制——0/负数/NaN/分数/字符串都能到这。**0/负数最危险**：让 start 落在 messages.length 或之后，循环读 `.role` 读 undefined 直接 throw 挂掉整个请求（maxMessagesWindow.ts:24-29 注释）。非法值归 null（不设限）而非猜数字：**服务全历史是既有行为、永不意外，发明一个窗口反而静默丢上下文**。

**对 CLWriting 借鉴**：
- 这是**最该立刻抄的一条**——CLWriting 的 `trimHistory`（chat.ts:82-100）就是"切在中间导致孤儿"的隐患，但没有 normalize 防线。若未来 maxMessages 从设置读，先套 normalizeMaxMessages。
- 现成的 applyMaxMessagesWindow 泛型函数可直接搬（50 行以内），CLWriting 的 maxMessages 窗口若做成设置项，直接套这两条修正。

**成本与优先级**：低 / 高

---

### 2.16 预算常量全景（constants.ts + contextSettings.ts）

**代码位置**：`src/main/ai/constants.ts:11-65`、`src/shared/data/types/contextSettings.ts:68-79`

**全部常量**：

| 常量 | 值 | 位置 | 含义 |
|---|---|---|---|
| CONTEXT_COMPACT_TRIGGER_RATIO | 0.8 | constants.ts:11 | 服务 prompt 超窗口 80% 触发压缩（两海拔 lockstep） |
| CONTEXT_COMPACT_KEEP_BUDGET_RATIO | 0.3 | constants.ts:12 | 保留窗口 30% 作为最近 verbatim 回合预算 |
| COMPACTION_INPUT_SAFETY_RATIO | 0.85 | constants.ts:23 | 压缩请求输入预算 = (window−output)×0.85 |
| COMPACTION_MIN_INPUT_BUDGET | 2000 | constants.ts:24 | 压缩输入预算下限 |
| IN_FLIGHT_TOOL_OUTPUT_WINDOW_RATIO | 0.1 | constants.ts:33 | in-flight tool 输出预算占窗口 10% |
| APPROX_CHARS_PER_TOKEN | 3 | constants.ts:43 | token 窗口 → 字符预算换算系数（保守偏小） |
| MIN_IN_FLIGHT_TRUNCATE_THRESHOLD | 2000 | constants.ts:50 | in-flight 截断阈值下限（<2000 无意义） |
| ATTACHMENT_INPUT_SAFETY_RATIO | 0.9 | constants.ts:57 | attachment 预算占输入房间 90% |
| MIN_INPUT_ROOM_RATIO | 0.2 | constants.ts:65 | contextWindow−outputReservation 的下限比例 |
| DEFAULT_MAX_TOKENS | 8192 | constants.ts:3 | 默认输出 token 上限 |
| DEFAULT_TIMEOUT | 30min | constants.ts:1 | 默认超时 |
| MIN_TRUNCATE_THRESHOLD | 2000 | contextSettings.ts:68 | 持久化截断阈值下限（renderer 也可用） |
| DEFAULT_CONTEXT_SETTINGS | … | contextSettings.ts:73-79 | 默认：enabled=true, truncateThreshold=50_000, maxMessages=null, compress.enabled=true |

**设计理由与踩坑**：
- **min floor 防"非正预算"**：`MIN_INPUT_ROOM_RATIO=0.2` 的存在是因为 registry 有 83 个模型 maxOutputTokens >= contextWindow，不减 floor 则所有窗口相对预算非正（#18318 的形状）。
- **字符/token 双轨**：in-flight 保护窗口用"token 比例 × APPROX_CHARS_PER_TOKEN"，persist lane 保护 DB 大小用"纯字符阈值"（窗口无关）——两个问题两把尺（constants.ts:26-32 注释）。
- **renderer 也能 import**：MIN_TRUNCATE_THRESHOLD 放 contextSettings.ts（shared）而非 main 常量，因为两个设置 UI 都要 clamp 同一数字（contextSettings.ts:64-67 注释）。

**对 CLWriting 借鉴**：
- CLWriting 现在没有窗口相对预算体系，起步建议只抄两条比例：**触发 0.8 / 保留 0.3** + **输入预算 (window−output)×0.85、下限 2000**。其余等有明确场景再加。

**成本与优先级**：低 / 高（常量就几条，但语义值得先定死）

---

### 2.17 resolveInputRoom 与 resolveCompressionOutputTokens：两个预算公式

**代码位置**：`src/main/ai/contextBuild/resolveInputRoom.ts:19-24`、`packages/aiCore/src/core/context/middleware.ts:65-73`

**核心公式**：

```ts
// 输入房间 = 请求实际声明的 max_tokens 从窗口里扣除后剩下的
export function resolveInputRoom(contextWindow, reservation: number | undefined): number {
  if (reservation === undefined) return contextWindow
  return Math.max(contextWindow - reservation, Math.floor(contextWindow * MIN_INPUT_ROOM_RATIO))
}                                          // resolveInputRoom.ts:19-24

// 压缩调用输出预算 = 压缩模型窗口的 25%，夹在 4096 ~ 16384
export function resolveCompressionOutputTokens(contextWindow?: number): number {
  if (!contextWindow || !Number.isFinite(contextWindow) || contextWindow <= 0) return COMPRESSION_MIN_OUTPUT_TOKENS
  const share = Math.floor(contextWindow * COMPRESSION_OUTPUT_WINDOW_RATIO)   // 0.25
  const ceiling = Math.min(COMPRESSION_MAX_OUTPUT_TOKENS, Math.max(1, contextWindow - 1))
  return Math.min(ceiling, Math.max(COMPRESSION_MIN_OUTPUT_TOKENS, share))
}                                          // middleware.ts:65-73
```

**设计理由与踩坑**：
- **所有窗口相对预算都该对 inputRoom 而不是裸 window**——回复要有落点（resolveInputRoom.ts:6-9 注释）。让 maxOutputTokens>=window 的模型拿到"永远花不完的预算"是旧 bug。
- **压缩输出预算的尺度问题**：从压缩模型窗口推，不是从聊天窗口推（一个 8k 压缩器配 128k 聊天，按聊天窗算会溢出压缩请求）。默认 4096 是**下夹**，真预算从窗口比例算（middleware.ts:40-47 注释）——上一个固定 2048 卡在 deepseek 的 thinking 边界上导致 text 空。
- 无窗口信息 → 返回下限 4096，绝不猜。

**对 CLWriting 借鉴**：
- 摘要/压缩调用预算的公式直接可用；CLWriting 若多个 provider 混用，注意"压缩模型窗口 != 聊天模型窗口"，预算要用压缩模型自己的。

**成本与优先级**：低 / 中

---

### 2.18 主进程两条压缩 lane 的预算落地（inLoopCompaction + PersistentChatContextProvider）

**代码位置**：`src/main/ai/runtime/aiSdk/params/features/inLoopCompaction.ts:115-294`、`src/main/ai/streamManager/context/PersistentChatContextProvider.ts:936-1069`

**设计理由与踩坑**（这是旧报告没展开的应用层细节）：
- **两条 lane 的 trigger/keep 预算共用同一常量**，避免两路径在 estimate===trigger 处不一致（constants.ts:6-10 注释）。
- **in-loop 的候选折叠**：每步 prepareStep 收到的是完整 `[...initialMessages, ...responseMessages]`，用 `foldCache` 记住"上次折叠吃了多少原始消息、压成什么"，下次只压 `[compactedPrefix, ...新消息]`，避免每次重压全历史（inLoopCompaction.ts:188-198）——运行时测量：没这个每步 44k→66k tokens/次摘要调用。
- **usage-first 估计**：`estimatePromptTokens` 锚定上一步真实 usage.totalTokens（仅当 inputTokens 也报告才信，防 output-only 塌缩），只 tokenx 估尾部 delta（工具结果）（inLoopCompaction.ts:83-106）。
- **computeKeepRecentTurns**：从尾部按"assistant+其 tool 段"累计 token 到 keepBudget，至少 1 回合（inLoopCompaction.ts:115-136）。
- **turn-start lane**：PersistentChatContextProvider 从 DB 行构造 `effective`（applyDeepestMarker 折叠最深摘要行），超 trigger 后 `planKeepBoundary` 从尾部累积到 keepBudget、snap 到 user 行（compaction.ts:136-154），再 summarizeModelMessages 折叠老段。空摘要/异常一律 settle 为 `skipped` 且**继续服务未压缩历史**（不造假"已压缩"标记）。
- **summaryRow 的 manifest**：被折叠的 attachment handle 和 persisted output path 以**只追加**的 manifest 行写进摘要行（compaction.ts:51-68），保证折叠后模型仍知道 read_file/fs_read 的合法参数；manifest 是边界的纯函数，后面挂附件不重写字节（前缀缓存存活）。

**对 CLWriting 借鉴**：
- CLWriting 若做长对话压缩，两条 lane 可以只取一条：**turn-start 持久化压缩**更贴合（书库行级摘要），in-loop 折叠缓存更适合工具循环。起步建议 turn-start。
- **空摘要/异常 → skipped 且不造假"已压缩"** 的纪律直接抄——避免 UI 谎报。

**成本与优先级**：中 / 中

---

### 2.19 相关测试的写法

**代码位置**：`packages/aiCore/src/core/context/__tests__/*.test.ts`、`src/main/ai/messages/__tests__/maxMessagesWindow.test.ts`

**测试模式归纳**：
1. **助手函数构造 fixture**：如 `buildHistory()` 用 `user('u1')/assistantTool('a2','call-1')/toolResult('t2','call-1')` 拼"system + 6 回合"（durableCompaction.test.ts:23-32），断言 contents 数组相等——**先定义"期望的回合边界"，再测 cut**。
2. **引用透传断言**：`expect(result).toBe(history)`——no-op 引用透传用 `toBe` 而非 `toEqual`（durableCompaction.test.ts:132-146）——这正是契约所在。
3. **边界值全测**：keepRecentTurns 取 0/负数/小数/超过回合数/恰好相等（durableCompaction.test.ts:61-111），planCompaction 的 floor/clamp 全路径。
4. **工具配对不切断**：断言 toSummarize/toKeep 的 contents 精确列（`['a2','t2','u3','a3']`），验证 tool 结果不与 assistant 分离（durableCompaction.test.ts:44-51）。
5. **mock 模型最小化**：V3 mock 模型只实现 doGenerate（返回固定文本 + usage），doStream 直接 throw（compactionModelMessages.test.ts:16-45）。
6. **测试"行为契约"而非快照**：如 `expect(result.prompt).toEqual(prompt)` 断言"未超阈值原样透传"（middleware.test.ts:139）。
7. **maxMessagesWindow.test.ts**：六种 case——无限制原样返回（toBe 引用）、窗口落在 user、向前扩展、assistant 结尾、无 user 行服务全部、非法值不 throw（maxMessagesWindow.test.ts:8-51）。**非法值用循环 `for (const bad of [0,-3,NaN,Infinity,'2',{}])` 批量断言不 throw 且返回原引用**——正是对 normalize 防线回归的写法。
8. **跨实现对拍**：Offloader 文件名用 node:crypto 算 sha256 前 16 与 Web Crypto 对拍（offloader.test.ts:253-263），锁定"两套实现字节一致"契约。
9. **防二次截断测试**：构造一个含 `<persisted-output>` 的 marker 当输入，断言原样返回（truncator.test.ts:57-69）。
10. **inLoopCompaction.test.ts**：mock `compactModelMessages`，断言 no-op 时 `toHaveBeenCalledTimes(0)`、no-op 引用判定 settle skipped、错误隔离（compactionDisabled）、foldCache 不重复摘要（test 全量 459 行，inLoopCompaction.test.ts:355-460 是 no-op 契约）。

**对 CLWriting 借鉴**：
- CLWriting 的 prompts.test.ts 已有 trimHistory/sanitizeHistory 测试（test/ai/prompts.test.ts:95-251），可参照补"回合不切断 tool 配对"、"非法窗口值不 throw"、"no-op 引用透传"三个维度的断言。
- **测试价值排序**：契约（不切断配对/不丢历史/不造假成功）> 边界值 > 内部实现。

**成本与优先级**：低 / 高（抄函数时顺手抄测试）

---

## 三、与 8-14 旧报告的差异补充

旧报告 CS-6 ~ CS-12 已宏观覆盖本专题，本文深挖后**补出新细节 / 修正旧认知**如下：

1. **旧 CS-7 只说了五步顺序**，没讲：预算开关显式（onBeforeCompress 触发 Janitor 构造，无则零开销）、contextWindow 缺失直接 throw、usage 缺失只警告一次、**in-flight 压缩连续 3 次告警"未持久化"**（middleware.ts:32-33, 168-180）——这条对 CLWriting 判断"什么时候必须持久化"极有用。
2. **旧 CS-8 提了引用透传但没讲 no-op 的两条触发**：`plan.toSummarize.length === 0` 和 `summary.trim() === ''`（durableCompaction.ts:94, 99），以及**空摘要必须 fail-open 保留历史**（createCompressionAdapter 绝不用占位符替代空输出，middleware.ts:353-359）——这是 #17837"空摘要被占位符吞掉历史"的修复，旧报告没提。
3. **旧 CS-9 没讲内容寻址的跨实现字节一致契约**：主进程 computeVfsFilename 与 Offloader 用 node:crypto / Web Crypto 算同款 `vfs_<sha256[:16]>.txt`（toolOutputStore.ts:30-33 + offloader.test.ts:253-263），且**写先于取物理路径**（DB 类 adapter 写才建记录）、exists() 只短路写不短路路径解析（offloader.ts:168-174）——这些是落地时最容易踩的。
4. **旧 CS-10 讲了渐进 stub + 保头尾，但没讲 clampToInputBudget 的保留顺序细节**：首条（可能是先前摘要）绝不可丢 + 尾部指令必须留 + 从尾向前贪心（janitor.ts:182-204），以及 STUB_ESCALATION 的 `threshold >= opts.toolResultStubThreshold` 保护（用户显式阈值不被降档）。
5. **旧报告完全没覆盖**：
   - **groupIntoTurns 的精确判定**（janitor.ts:40-63）与"只认连续 tool 段"的规则；
   - **E10 抑制机制**（janitor.ts:335, 392-395）防级联压缩；
   - **onBeforeCompress 结果被再评估**（janitor.ts:368-374）；
   - **两套 adapter 的 `_mm*` / `_*` 前缀隔离**与无损往返的 `_originalText` 变更检测（adapter.ts:203）；
   - **provider 内联 tool-result 防重复注入**（adapter.ts:103-110）；
   - **ensureValidHistory 注入合成 tool 结果时带 tool 名**（防 Gemini/strict 校验拒绝，ensureValidHistory.ts:88-93）；
   - **主进程两条 lane 的预算公式**（resolveInputRoom / resolveCompressionOutputTokens / computeKeepRecentTurns / planKeepBoundary）与 in-loop foldCache 防重复摘要（inLoopCompaction.ts:188-198）；
   - **summaryRow 的 manifest 只追加契约**（compaction.ts:27-49, 51-68）；
   - **全部常量数值**（2.16 表）——旧报告一个都没给。
6. **旧报告把 CS-12 描述为"窗口必须落在 user 上"**，正确；但**没讲"role-only 切片为什么够"**（v2 chat 的 tool 调用嵌在 assistant parts 内，行级切片不可能 orphan tool 结果，maxMessagesWindow.ts:11-12）和**"早期返回刻意不做归一化"**（maxMessagesWindow.ts:14-18）这两条设计取舍，以及 normalize 的"0/负数会导致读 undefined 挂请求"的具体崩溃路径（maxMessagesWindow.ts:24-29）。
7. **旧报告测试写法只提了"禁止行为固化测试"原则**，本文 2.19 给出了具体可抄的 fixture 构造 / toBe 引用断言 / 非法值批量断言 / 跨实现对拍 等模式。

## 四、不值得抄的部分

1. **AI SDK LanguageModelMiddleware 机制本身**：CLWriting 是自研 provider 层，不引 `@ai-sdk/provider` 就没有 middleware 可挂；抄的是**内部五步逻辑**（截断→机械→分离→预算→重组），不是挂载机制。
2. **pruneMessages 的完整 option 面**：`before-last-N-messages` 模板字面量、按 tool 名数组裁剪等是给大型 agent 工具生态设计的；CLWriting 起步只需 `emptyMessages: remove` + `toolCalls: before-last-1` 两档。
3. **EntityToolOutputCodec 的 JSON-pointer-lite 契约**：为"结构化 tool 输出持久化信封复用"设计，CLWriting 没有跨实现 inflate 需求，可不做（保留简单字符串截断即可）。
4. **VFS getPhysicalPath + fs_read 的读取回传协议**：CLWriting 的工具读回可以用自己已有的读文件能力，不需要 context://vfs/ URI 方案和 FsReadTool 的 7 字符 gutter / paging 契约（那套是为"模型有现成 fs_read 工具"设计的）。
5. **in-flight Janitor 的 E10 抑制 + feedTokenUsage 双轨**：CLWriting 若一次生成即一轮（无连续步骤），单次预算检查即可，不需要"跨调用累计 token"的 Janitor 状态机——**只要 evaluateBudget + onBeforeCompress 再评估 + 机械兜底**三段。
6. **in-loop foldCache 与 compactionSink 锚点**：为"每步 prepareStep 重压全历史"的工具循环优化；CLWriting 对话助手 ≤5 轮，暂时用不上，等长工具循环出现再抄。
7. **两条 lane 共用常量的 lockstep 纪律**：CLWriting 只做一条 lane（turn-start）时，不需要"两处保持同步"的工程约束。
8. **attachment [image]/[document] 占位**：CLWriting 目前无图片进上下文场景，可留到接入图片时再抄。

## 五、给综合报告的 Top-N 建议摘要

按"对 CLWriting 价值 × 落地成本"排序：

1. **【高价值/低成本】maxMessagesWindow + normalizeMaxMessages**（2.15）——50 行以内，直接套到对话助手窗口，消除"窗口切在 assistant 中间导致孤儿回复"和"非法设置值挂请求"两个隐患。对应旧批次 A1。
2. **【高价值/低成本】groupIntoTurns + no-op 引用透传**（2.4 + 2.5）——先落地 turn 分组纯函数（含测试），再把"压缩/裁剪 no-op 返回原引用"纪律铺到 CLWriting 所有持久化点。对应旧批次 B1 的核心。
3. **【高价值/中成本】五步管线中的"先机械后智能 + system 永不裁 + 空摘要 fail-open"三纪律**（2.2 + 2.8 + 2.9）——CLWriting 的审查/润色长文注入上下文前套"渐进裁剪 + 保头尾 + 声明遗漏"，摘要空时保留原历史绝不造假。对应旧批次 B1/B2。
4. **【中价值/低成本】摘要指令 + 续写框架 + 两段式 analysis/summary**（2.10）——中文版模板直接可写，审查报告/自愈闭环失败记录通用。对应旧批次 B2 的 DSH-4 侧。
5. **【中价值/中成本】VFS 内容寻址外置**（2.6）——长章节正文/设定 dump 进上下文前先外置 + 头尾摘录，内容寻址保幂等。对应旧批次 B3。
6. **【低成本/高优先级】预算常量语义定死**（2.16）——触发 0.8 / 保留 0.3 / 输入预算 (window−output)×0.85 下限 2000 / 输出预算窗口 25% 夹 4096~16384，先写进 CLWriting 常量文件备用。

> 核心取舍一句话：**优先抄"回合语义 + 预算纪律 + fail-open"三类算法与常量，跳过 AI SDK middleware 挂载机制、VFS 读回协议、in-flight 状态机等外围工程**。
